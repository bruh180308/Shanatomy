"""Own macOS keychain item only; no key in a shell argument or disk file."""
import ctypes,hashlib,plistlib,re,subprocess
SERVICE=b'vn.hungle.shanatomy.license';ACCOUNT=b'Shanatomy'

def machine_id():
    result=subprocess.run(['/usr/sbin/ioreg','-rd1','-c','IOPlatformExpertDevice','-a'],capture_output=True,check=True,timeout=10)
    records=plistlib.loads(result.stdout)
    value=next((r.get('IOPlatformUUID') for r in records if isinstance(r,dict) and r.get('IOPlatformUUID')),None)
    if not isinstance(value,str) or not re.fullmatch(r'[0-9a-fA-F-]{36}',value):raise RuntimeError('Không đọc được mã máy Mac.')
    return hashlib.sha256(('Shanatomy:macOS:'+value.lower()).encode()).hexdigest()

def libraries():
    sec=ctypes.CDLL('/System/Library/Frameworks/Security.framework/Security')
    cf=ctypes.CDLL('/System/Library/Frameworks/CoreFoundation.framework/CoreFoundation')
    ptr=ctypes.c_void_p;u32=ctypes.c_uint32
    sec.SecKeychainFindGenericPassword.argtypes=[ptr,u32,ctypes.c_char_p,u32,ctypes.c_char_p,ctypes.POINTER(u32),ctypes.POINTER(ptr),ctypes.POINTER(ptr)]
    sec.SecKeychainFindGenericPassword.restype=ctypes.c_int32
    sec.SecKeychainAddGenericPassword.argtypes=[ptr,u32,ctypes.c_char_p,u32,ctypes.c_char_p,u32,ptr,ctypes.POINTER(ptr)]
    sec.SecKeychainAddGenericPassword.restype=ctypes.c_int32
    sec.SecKeychainItemModifyAttributesAndData.argtypes=[ptr,ptr,u32,ptr];sec.SecKeychainItemModifyAttributesAndData.restype=ctypes.c_int32
    sec.SecKeychainItemFreeContent.argtypes=[ptr,ptr];cf.CFRelease.argtypes=[ptr]
    return sec,cf

def load_key():
    sec,cf=libraries();length=ctypes.c_uint32();data=ctypes.c_void_p();item=ctypes.c_void_p()
    code=sec.SecKeychainFindGenericPassword(None,len(SERVICE),SERVICE,len(ACCOUNT),ACCOUNT,ctypes.byref(length),ctypes.byref(data),ctypes.byref(item))
    if code==-25300:return ''
    if code:raise RuntimeError('Keychain chưa cho phép đọc key.')
    try:
        if length.value>1024:raise RuntimeError('Keychain trả dữ liệu không hợp lệ.')
        return ctypes.string_at(data,length.value).decode('utf8')
    finally:
        if data:sec.SecKeychainItemFreeContent(None,data)
        if item:cf.CFRelease(item)

def store_key(key):
    sec,cf=libraries();item=ctypes.c_void_p();data=key.encode('utf8');buffer=ctypes.create_string_buffer(data)
    code=sec.SecKeychainFindGenericPassword(None,len(SERVICE),SERVICE,len(ACCOUNT),ACCOUNT,None,None,ctypes.byref(item))
    try:
        if code==0:code=sec.SecKeychainItemModifyAttributesAndData(item,None,len(data),buffer)
        elif code==-25300:code=sec.SecKeychainAddGenericPassword(None,len(SERVICE),SERVICE,len(ACCOUNT),ACCOUNT,len(data),buffer,None)
        if code:raise RuntimeError('Keychain chưa cho phép lưu key. Hãy cho phép riêng Shanatomy rồi thử lại.')
    finally:
        if item:cf.CFRelease(item)
