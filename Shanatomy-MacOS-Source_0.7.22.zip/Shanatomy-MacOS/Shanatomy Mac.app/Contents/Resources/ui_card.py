"""One symmetric antialiased rounded card, independent of display scaling."""
import math

def card_ppm(width=456,height=370):
    background=(16,25,30);fill=(23,35,40);stroke=(79,117,104)
    rows=[];cx=width/2;cy=height/2;hx=width/2-14;hy=height/2-14;radius=24
    for y in range(height):
        row=bytearray();qy=abs(y+.5-cy)-(hy-radius)
        for x in range(width):
            qx=abs(x+.5-cx)-(hx-radius)
            d=math.hypot(max(qx,0),max(qy,0))+min(max(qx,qy),0)-radius
            coverage=max(0,min(1,.5-d));border=max(0,min(1,d+2))
            for a,b,c in zip(background,fill,stroke):row.append(round(a*(1-coverage)+(b*(1-border)+c*border)*coverage))
        rows.append(row)
    return f'P6\n{width} {height}\n255\n'.encode()+b''.join(rows)

def draw_card(canvas):
    import tkinter as tk
    image=tk.PhotoImage(master=canvas,data=card_ppm(),format='PPM')
    canvas.card_image=image
    return canvas.create_image(0,0,image=image,anchor='nw')
