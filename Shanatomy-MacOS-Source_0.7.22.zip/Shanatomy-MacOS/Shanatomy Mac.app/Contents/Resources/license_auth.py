"""KeyAuth 1.3 license-only client. No administrative credentials."""
import ctypes,hashlib,json,os,queue,threading,time,urllib.request,urllib.parse
from pathlib import Path
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

APP_NAME='Shanatomy';OWNER_ID='EV6jVLnFyQ';AUTH_VERSION='1.0'
API='https://keyauth.win/api/1.3/'
SERVER_KEY='5586b4bc69c7a4b487e4563a4cd96afd39140f919bd31cea7d1c6a1e8439422b'
class AuthError(Exception):pass
class NetworkError(AuthError):pass
class Rejected(AuthError):pass
class SessionExpired(Rejected):pass
class UpdateUnavailable(Exception):pass

def machine_id():
    from mac_security import machine_id as mac_id
    try:return mac_id()
    except Exception as e:raise AuthError('Không đọc được mã máy Mac.') from e

def verified_response(body,headers,now=time.time,public_key=SERVER_KEY):
    try:
        stamp=headers['x-signature-timestamp'];signature=headers['x-signature-ed25519']
        if abs(now()-int(stamp))>25:raise ValueError('stale timestamp')
        Ed25519PublicKey.from_public_bytes(bytes.fromhex(public_key)).verify(bytes.fromhex(signature),stamp.encode()+body)
        data=json.loads(body)
        if not isinstance(data,dict) or type(data.get('success')) is not bool:raise ValueError('invalid response')
        return data
    except Exception as e:raise AuthError('Không thể xác minh. Kiểm tra ngày giờ Mac.') from e

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):raise AuthError('KeyAuth chuyển hướng bất thường.')
def request(fields):
    req=urllib.request.Request(API,data=urllib.parse.urlencode(fields).encode(),headers={'User-Agent':'Shanatomy-License','Content-Type':'application/x-www-form-urlencoded'})
    try:
        with urllib.request.build_opener(NoRedirect()).open(req,timeout=15) as r:
            body=r.read(128*1024+1)
            if len(body)>128*1024:raise AuthError('Phản hồi KeyAuth quá lớn.')
            return verified_response(body,r.headers)
    except AuthError:raise
    except (OSError,TimeoutError) as e:raise NetworkError('Không có kết nối. Vui lòng thử lại.') from e

def failure(data):
    text=str(data.get('message','')).lower()
    if 'hwid' in text:return 'Key đã gắn với máy khác. Liên hệ để reset.'
    if 'expired' in text:return 'Key đã hết hạn. Vui lòng gia hạn.'
    if 'ban' in text:return 'Key hoặc máy đã bị khóa.'
    if 'invalidver' in text:return 'Phiên bản KeyAuth chưa khớp. App KeyAuth cần đặt Version 1.0.'
    if 'invalid' in text or 'not found' in text:return 'Key không hợp lệ hoặc ứng dụng KeyAuth chưa được cấu hình đúng.'
    return 'KeyAuth từ chối xác thực. Kiểm tra trạng thái app/key trên dashboard.'

class Client:
    def __init__(self,transport=request,hwid=machine_id,now=time.time):
        self._lock=threading.RLock();self.transport=transport;self.hwid_fn=hwid;self.now=now;self.session='';self.expires=0;self.valid=False;self.last_verified=0;self.key=''
    def call(self,kind,**extra):
        data=self.transport({'type':kind,'name':APP_NAME,'ownerid':OWNER_ID,**({'sessionid':self.session} if self.session else {}),**extra})
        if not data.get('success'):
            text=str(data.get('message','')).lower()
            if 'session' in text and any(x in text for x in ('invalid','expired','not found','does not exist')):raise SessionExpired('Phiên xác thực đã hết hạn.')
            self.valid=False
            raise Rejected(failure(data))
        return data
    def initialize(self):
        if not self.session:
            data=self.call('init',ver=AUTH_VERSION)
            self.session=data.get('sessionid','')
            if not isinstance(self.session,str) or not self.session:raise AuthError('Thiếu phiên xác thực KeyAuth.')
    def activate(self,key):
        key=key.strip()
        if not key or len(key)>256:raise Rejected('Nhập key hợp lệ.')
        self.initialize();hwid=self.hwid_fn()
        try:data=self.call('license',key=key,hwid=hwid)
        except SessionExpired:
            self.session='';self.initialize();data=self.call('license',key=key,hwid=hwid)
        try:
            info=data.get('info',{})
            if not isinstance(info,dict):raise Rejected('Phản hồi gói sử dụng không hợp lệ.')
            if info.get('hwid')!=hwid:raise Rejected('KeyAuth chưa xác nhận khóa cho máy này. Hãy bật HWID Lock và Force HWID.')
            try:expiry=max(int(sub['expiry']) for sub in info.get('subscriptions',[]) if isinstance(sub,dict))
            except (ValueError,KeyError,TypeError):raise Rejected('Key chưa có gói sử dụng hợp lệ.')
            if expiry<=self.now():raise Rejected('Key đã hết hạn.')
        except AuthError:
            with self._lock:self.valid=False
            raise
        # Do not briefly publish valid=False during a successful background refresh.
        with self._lock:self.expires=expiry;self.last_verified=self.now();self.valid=True;self.key=key
        return self.snapshot()
    def snapshot(self):
        with self._lock:return {'valid':self.valid and self.now()<self.expires,'expires':self.expires,'device_bound':True,'auth_version':AUTH_VERSION}
    def refresh(self):
        if not self.snapshot()['valid']:self.valid=False;raise Rejected('Key đã hết hạn.')
        try:
            try:self.call('check')
            except SessionExpired:self.session=''
            self.activate(self.key)
        except NetworkError:
            if self.now()-self.last_verified>900:self.valid=False;raise
            return
        except AuthError:self.valid=False;raise

def saved_key(state):
    from mac_security import load_key
    try:return load_key()
    except (OSError,RuntimeError,UnicodeError):return ''

def save_key(state,key):
    from mac_security import store_key
    try:store_key(key)
    except (OSError,RuntimeError) as e:raise AuthError(str(e)) from e


def activation_dialog(root,state,client=None,after_auth=None):
    """Dark rounded controls; all animations and widget work stay on Tk thread."""
    import tkinter as tk
    client=client or Client();events=queue.Queue();done={'ok':False,'closed':False};saved=''
    win=tk.Toplevel(root);win.withdraw();win.title('Shanatomy');win.configure(bg='#010203');win.resizable(False,False)
    win.overrideredirect(True)
    try:win.attributes('-transparent',True);win.configure(bg='systemTransparent')
    except tk.TclError:win.configure(bg='#10191e')
    width,height=456,370;win.geometry(f'{width}x{height}+{max(0,(win.winfo_screenwidth()-width)//2)}+{max(0,(win.winfo_screenheight()-height)//2)}')
    canvas=tk.Canvas(win,width=width,height=height,bg=win['bg'],highlightthickness=0);canvas.pack(fill='both',expand=True)
    def rounded(x,y,w,h,r,**kw):
        return canvas.create_polygon(x+r,y,x+w-r,y,x+w,y,x+w,y+r,x+w,y+h-r,x+w,y+h,x+w-r,y+h,x+r,y+h,x,y+h,x,y+h-r,x,y+r,x,y,smooth=True,splinesteps=24,**kw)
    from ui_card import draw_card
    draw_card(canvas)
    rounded(387,28,32,32,16,fill='#223237',outline='',tags='close')
    canvas.create_line(398,39,408,49,fill='#a9c5bb',width=1.6,tags='close')
    canvas.create_line(408,39,398,49,fill='#a9c5bb',width=1.6,tags='close')
    canvas.tag_bind('close','<Enter>',lambda e:(canvas.itemconfigure('close',fill='#80d8b3'),canvas.itemconfigure(canvas.find_withtag('close')[0],fill='#304b43')))
    canvas.tag_bind('close','<Leave>',lambda e:(canvas.itemconfigure('close',fill='#a9c5bb'),canvas.itemconfigure(canvas.find_withtag('close')[0],fill='#223237')))
    drag={'origin':None}
    def start_drag(event):
        if event.y>65 or 'close' in canvas.gettags('current'):return
        drag['origin']=(event.x_root,event.y_root,win.winfo_x(),win.winfo_y())
    def move_drag(event):
        if not event.state & 0x100:drag['origin']=None;return
        if drag['origin']:
            x,y,wx,wy=drag['origin'];win.geometry(f'+{max(0,wx+event.x_root-x)}+{max(0,wy+event.y_root-y)}')
    canvas.bind('<ButtonPress-1>',start_drag);canvas.bind('<B1-Motion>',move_drag)
    win.bind('<ButtonRelease-1>',lambda e:drag.update(origin=None));win.bind('<FocusOut>',lambda e:drag.update(origin=None))
    canvas.create_text(34,43,text='SHANATOMY',anchor='w',fill='#80d8b3',font=('Helvetica Neue',10,'bold'))
    canvas.create_text(34,86,text='Vui lòng nhập key',anchor='w',fill='#edf7f4',font=('Helvetica Neue',23,'bold'))
    canvas.create_text(34,121,text='Kích hoạt Shanatomy',anchor='w',fill='#91afa3',font=('Helvetica Neue',10))
    canvas.create_text(34,157,text='KEY XÁC THỰC',anchor='w',fill='#91afa3',font=('Helvetica Neue',9,'bold'))
    field=rounded(34,176,388,52,13,fill='#10191e',outline='#344a48',width=1)
    entry=tk.Entry(win,show='•',font=('Helvetica Neue',12),bg='#10191e',fg='#edf7f4',disabledbackground='#10191e',disabledforeground='#91afa3',insertbackground='#80d8b3',relief='flat',highlightthickness=0,selectbackground='#396b59',selectforeground='#ffffff')
    canvas.create_window(49,202,window=entry,width=308,height=30,anchor='w')
    eye=tk.Label(win,text='Hiện',bg='#10191e',fg='#91afa3',font=('Helvetica Neue',9),cursor='hand2',takefocus=True);canvas.create_window(393,202,window=eye)
    def show_key(event=None):entry.configure(show='' if entry['show'] else '•');eye.configure(text='Ẩn' if entry['show']=='' else 'Hiện')
    eye.bind('<Button-1>',show_key);eye.bind('<space>',show_key);eye.bind('<Enter>',lambda e:eye.configure(fg='#80d8b3'));eye.bind('<Leave>',lambda e:eye.configure(fg='#91afa3'))
    entry.bind('<FocusIn>',lambda e:canvas.itemconfigure(field,outline='#80d8b3'));entry.bind('<FocusOut>',lambda e:canvas.itemconfigure(field,outline='#344a48'))
    feedback=canvas.create_text(34,249,text='Key được lưu bảo mật.',anchor='nw',width=388,fill='#91afa3',font=('Helvetica Neue',10))
    button=rounded(34,300,388,42,12,fill='#80d8b3',outline='',tags='check')
    label=canvas.create_text(228,321,text='Kiểm tra',fill='#10251e',font=('Helvetica Neue',11,'bold'),tags='check')
    progress=canvas.create_line(38,291,38,291,fill='#80d8b3',width=2,state='hidden')
    ui={'busy':False,'hover':False,'tone':0.0,'target':0.0,'phase':0}
    def hover(on):
        if done['closed']:return
        ui['hover']=on;ui['target']=1.0 if on and not ui['busy'] else 0.0;canvas.configure(cursor='hand2' if on and not ui['busy'] else '')
    canvas.tag_bind('check','<Enter>',lambda e:hover(True));canvas.tag_bind('check','<Leave>',lambda e:hover(False))
    def submit(event=None):
        if ui['busy'] or ui.get('finishing') or done['closed']:return
        if ui.get('continue_ready'):
            if not client.snapshot()['valid']:
                ui['continue_ready']=False;canvas.itemconfigure(feedback,text='Key đã hết hạn. Vui lòng kiểm tra lại.',fill='#f1b5a7');entry.configure(state='normal');canvas.itemconfigure(label,text='Kiểm tra');return
            done['ok']=True;close();return
        key=entry.get().strip()
        if not key:canvas.itemconfigure(feedback,text='Vui lòng nhập key.',fill='#f1b5a7');entry.focus_set();return
        ui['busy']=True;ui['target']=0;entry.configure(state='disabled');canvas.itemconfigure(label,text='Đang kiểm tra…');canvas.itemconfigure(feedback,text='Đang xác thực…',fill='#91afa3');canvas.itemconfigure(progress,state='normal')
        def work():
            try:
                client.activate(key)
                if done['closed']:return
                try:save_key(state,key)
                except (AuthError,OSError):client.key_storage_warning=True
                if after_auth:
                    def notify(value):events.put(('update',value))
                    try:mode=after_auth(client,notify,lambda:done['closed'])
                    except UpdateUnavailable:
                        if getattr(getattr(client,'updater',None),'pending',None):
                            client.restart_requested=True
                            if not done['closed']:events.put((True,''))
                            return
                        if not done['closed']:events.put(('update_error','Chưa cập nhật được. Có thể dùng bản hiện tại.'))
                        return
                    if mode=='cancelled' or done['closed']:return
                    client.restart_requested=mode=='restart'
                events.put((True,''))
            except AuthError as e:events.put((False,str(e)))
            except Exception:events.put((False,'Chưa chuẩn bị được ứng dụng. Vui lòng thử lại.'))
        threading.Thread(target=work,daemon=True).start()
    canvas.tag_bind('check','<Button-1>',submit);entry.bind('<Return>',submit)
    pending_callbacks=set()
    def schedule(delay,callback):
        def run():
            pending_callbacks.discard(identifier)
            callback()
        identifier=win.after(delay,run);pending_callbacks.add(identifier)
        return identifier
    def fade(start,end,finish=None):
        frames=10
        def step(n=0):
            t=n/frames;alpha=start+(end-start)*(1-(1-t)**3)
            try:win.attributes('-alpha',alpha)
            except tk.TclError:
                if finish:finish()
                return
            if n<frames:schedule(15,lambda:step(n+1))
            elif finish:finish()
        step()
    def close():
        if done['closed']:return
        done['closed']=True
        for identifier in list(pending_callbacks):
            try:win.after_cancel(identifier)
            except tk.TclError:pass
        pending_callbacks.clear();fade(1,0,win.destroy)
    win.protocol('WM_DELETE_WINDOW',close);win.bind('<Escape>',lambda e:close());win.bind('<Command-q>',lambda e:close());win.bind('<Command-w>',lambda e:close())
    canvas.tag_bind('close','<Button-1>',lambda e:close())
    entry.bind('<KeyPress>',lambda e:ui.update(edited=True),add='+')
    def start_saved_key():
        def load():
            key=saved_key(state)
            if not done['closed']:events.put(('saved_key',key))
        threading.Thread(target=load,daemon=True).start()
    def tick():
        if done['closed']:return
        try:
            ok,text=events.get_nowait()
            if ok=='saved_key':
                if text and not ui.get('edited') and not entry.get() and not ui['busy']:
                    entry.insert(0,text);schedule(100,submit)
            elif ok=='update':
                state=text.get('state');ui['update_state']=state;canvas.itemconfigure(feedback,text=text.get('message',''),fill='#91afa3')
                canvas.itemconfigure(label,text='Đang tải…' if state=='downloading' else 'Đang cập nhật…' if state=='staged' else 'Đang chuẩn bị…' if state=='preparing' else 'Đang kiểm tra bản mới…')
                ui['download_progress']=text.get('progress') if state in ('downloading','staged') else None
            elif ok=='update_error':
                ui['busy']=False;ui['continue_ready']=True;canvas.itemconfigure(progress,state='hidden');canvas.itemconfigure(feedback,text=text,fill='#f1c278');canvas.itemconfigure(label,text='Mở ứng dụng')
            else:
                ui['busy']=False;canvas.itemconfigure(progress,state='hidden')
                if ok:
                    ui['finishing']=True;canvas.itemconfigure(label,text='Khởi động lại…' if getattr(client,'restart_requested',False) else 'Thành công');canvas.itemconfigure(feedback,text='Đã xác minh bản mới.' if getattr(client,'restart_requested',False) else 'Đang mở ứng dụng…',fill='#80d8b3');done['ok']=True;schedule(220,close)
                else:
                    canvas.itemconfigure(feedback,text=text,fill='#f1b5a7');canvas.itemconfigure(label,text='Kiểm tra');entry.configure(state='normal');entry.focus_set()
        except queue.Empty:pass
        ui['tone']+=(ui['target']-ui['tone'])*.2;t=ui['tone']
        rgb=[round(a+(b-a)*t) for a,b in zip((128,216,179),(163,236,204))]
        color='#'+''.join(f'{v:02x}' for v in rgb);canvas.itemconfigure(button,fill='#355b4e' if ui['busy'] else color)
        if ui['busy']:
            if ui.get('download_progress') is not None:
                progress_value=max(0,min(100,ui['download_progress']));canvas.coords(progress,38,291,38+380*progress_value/100,291);canvas.itemconfigure(label,text=('Khởi động lại…' if getattr(client,'restart_requested',False) or ui.get('update_state')=='staged' else 'Đang tải '+str(progress_value)+'%'))
            else:
                ui['phase']=(ui['phase']+5)%464;x=ui['phase']-76;canvas.coords(progress,min(418,max(38,38+x)),291,min(418,max(38,38+x+76)),291)
        schedule(16 if ui['busy'] or abs(ui['target']-ui['tone'])>.01 else 80,tick)
    try:win.attributes('-alpha',0)
    except tk.TclError:pass
    win.deiconify();fade(0,1);tick();entry.focus_set()
    start_saved_key()
    root.wait_window(win)
    import gc
    gc.collect()
    return client if done['ok'] else None
