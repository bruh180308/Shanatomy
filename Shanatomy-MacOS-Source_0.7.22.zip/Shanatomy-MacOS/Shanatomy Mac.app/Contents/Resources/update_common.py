"""Signed GitHub release updates; no app termination or credentials in clients."""
import base64,hashlib,json,os,re,shutil,subprocess,sys,threading,time,urllib.request
from pathlib import Path
from urllib.parse import urlparse
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

MAX_EXE=200*1024*1024
def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode('utf8')
def digest(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def version(value):
    if not re.fullmatch(r'\d+\.\d+\.\d+',str(value)):raise ValueError('Phiên bản cập nhật không hợp lệ.')
    return tuple(map(int,value.split('.')))
def repository(value):
    value=str(value).strip().rstrip('/')
    if value.startswith('https://github.com/'):value=value[len('https://github.com/'):]
    if not re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+',value) or '..' in value:raise ValueError('Nhập địa chỉ kho https://github.com/tên/kho.')
    return value
def allowed_url(url):
    p=urlparse(url)
    if p.scheme!='https' or p.username or p.password or p.port not in (None,443) or p.hostname not in ('github.com','api.github.com','release-assets.githubusercontent.com','objects.githubusercontent.com'):raise ValueError('Địa chỉ tải không được phép.')
    return url
class SafeRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,headers,newurl):
        allowed_url(newurl)
        return super().redirect_request(req,fp,code,msg,headers,newurl)
def fetch(url,limit,output=None,progress=lambda n:None):
    allowed_url(url)
    request=urllib.request.Request(url,headers={'User-Agent':'Shanatomy-Updater','Accept':'application/octet-stream'})
    with urllib.request.build_opener(SafeRedirect()).open(request,timeout=8 if output is None else 20) as response:
        allowed_url(response.url)
        if int(response.headers.get('Content-Length','0'))>limit:raise ValueError('Tệp cập nhật vượt giới hạn.')
        chunks=[];count=0;started=time.monotonic();stream=output.open('wb') if output else None
        try:
            while True:
                chunk=response.read(128*1024)
                if not chunk:break
                if time.monotonic()-started>900:raise TimeoutError('Tải quá lâu. Hãy thử lại.')
                count+=len(chunk)
                if count>limit:raise ValueError('Tệp cập nhật vượt giới hạn.')
                if stream:stream.write(chunk)
                else:chunks.append(chunk)
                progress(count)
        finally:
            if stream:stream.close()
        return count if output else b''.join(chunks)
def verify(envelope,key,repo,app_version):
    payload=envelope['payload']
    Ed25519PublicKey.from_public_bytes(base64.b64decode(key,validate=True)).verify(base64.b64decode(envelope['signature'],validate=True),canonical(payload))
    version(payload['version'])
    if payload.get('schema')!=1 or payload.get('platform')!='windows-x64':raise ValueError('Gói cập nhật không dành cho Windows.')
    if payload.get('supported_app_version')!=app_version:raise ValueError('Bản mới chưa tương thích phiên bản Complete Anatomy của bạn.')
    asset=payload['asset'];url=allowed_url(asset['url']);p=urlparse(url)
    if p.hostname!='github.com' or not p.path.startswith('/'+repository(repo)+'/releases/download/') or p.query or p.fragment:raise ValueError('Gói cập nhật không thuộc kho đã chọn.')
    if not re.fullmatch(r'[a-f0-9]{64}',asset['sha256']) or not isinstance(asset['size'],int) or not 0<asset['size']<=MAX_EXE:raise ValueError('Thông tin tệp không hợp lệ.')
    if len(str(payload.get('notes','')))>8000:raise ValueError('Ghi chú quá dài.')
    return payload
def atomic_json(path,value):
    path.parent.mkdir(parents=True,exist_ok=True);temp=path.with_suffix('.tmp');temp.write_text(json.dumps(value,ensure_ascii=False),encoding='utf8');os.replace(temp,path)

def valid_target(target):
    target=Path(target)
    return target.is_absolute() and bool(re.fullmatch(r'(?:VietHoa_CompleteAnatomy_[0-9.]+|Shanatomy-Windows|Shanatomy)\.exe',target.name)) and not target.is_symlink() and not target.parent.is_symlink()

