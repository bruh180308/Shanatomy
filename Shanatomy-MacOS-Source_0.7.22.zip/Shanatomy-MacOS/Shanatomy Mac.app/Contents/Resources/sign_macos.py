"""Offline signing on the maintainer's Windows/Mac, private key never shipped."""
import argparse,base64,json,plistlib,shutil,tempfile
from pathlib import Path
from cryptography.hazmat.primitives import serialization
from update_common import canonical,digest,repository
from mac_updater import extract_app,bundle_kind,verify_macos
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--zip',required=True);p.add_argument('--version',required=True);p.add_argument('--kind',choices=['python-shell-app','self-contained-app'],required=True);p.add_argument('--key',required=True);p.add_argument('--out',required=True);p.add_argument('--tag');p.add_argument('--repo',default='bruh180308/Shanatomy');p.add_argument('--notes',default='Shanatomy Mac: menu0.7.22, key gắn máy, cập nhật online và phục hồi cache.');a=p.parse_args()
    source=Path(a.zip);out=Path(a.out);out.mkdir(parents=True,exist_ok=True);tag=a.tag or a.version
    if not tag or '/' in tag or len(tag)>80:raise ValueError('Tag không hợp lệ.')
    key=serialization.load_pem_private_key(Path(a.key).read_bytes(),None);pub=base64.b64encode(key.public_key().public_bytes(serialization.Encoding.Raw,serialization.PublicFormat.Raw)).decode();pinned=json.loads(Path(__file__).with_name('update_public_key.json').read_text(encoding='utf-8-sig'))['ed25519']
    if pub!=pinned:raise ValueError('Khóa ký không khớp public key đã ghim.')
    with tempfile.TemporaryDirectory() as temp:
        app=extract_app(source,Path(temp)/'verify.app')
        with (app/'Contents/Info.plist').open('rb') as f:info=plistlib.load(f)
        if info['CFBundleShortVersionString']!=a.version or bundle_kind(app)!=a.kind:raise ValueError('Phiên bản/kiểu ZIP không khớp yêu cầu ký.')
    payload={'schema':1,'version':a.version,'platform':'macos-apple-silicon','cache_schema':1,'package_kind':a.kind,'notes':a.notes,'asset':{'url':f'https://github.com/{repository(a.repo)}/releases/download/{tag}/Shanatomy-MacOS.zip','sha256':digest(source),'size':source.stat().st_size}}
    envelope={'payload':payload,'signature':base64.b64encode(key.sign(canonical(payload))).decode()};verify_macos(envelope,pinned,a.repo)
    if source.resolve()!=(out/'Shanatomy-MacOS.zip').resolve():shutil.copy2(source,out/'Shanatomy-MacOS.zip')
    (out/'update-macos.json').write_text(json.dumps(envelope,ensure_ascii=False,indent=2),encoding='utf8');print('Đã chuẩn bị ZIP Mac và update-macos.json đã ký; không chứa private key.')
