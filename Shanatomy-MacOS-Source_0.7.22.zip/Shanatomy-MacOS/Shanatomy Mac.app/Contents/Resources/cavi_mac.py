"""macOS test launcher: owns one cache HTML addition and one JS file only."""
import re,argparse,hashlib,json,os,plistlib,secrets,shutil,subprocess,sys,threading,time
from pathlib import Path
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from urllib.parse import urlparse

HERE=Path(getattr(sys,'_MEIPASS',Path(__file__).resolve().parent))
ASSETS=HERE/'assets'
VERSION='0.7.22'
DISCOVERY_NOTES=[]
LAST_DISCOVERED_APPS=[]
MARKER=b'<!-- ca-vi-macos-owned-bootstrap -->'

def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def save(p,value):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    temp=p.with_name(p.name+'.tmp');temp.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf8');os.replace(temp,p)
def guarded(p,root):
    p=Path(p);root=Path(root)
    if not p.resolve().is_relative_to(root.resolve()):raise RuntimeError('Tệp nằm ngoài cache đã chọn.')
    for node in [p,*p.parents]:
        if node.is_symlink():raise RuntimeError('Không sửa đường dẫn qua liên kết tượng trưng.')
def atomic(p,data,expected,root):
    guarded(p,root)
    if (sha(p) if p.exists() else None)!=expected:raise RuntimeError('Cache vừa thay đổi; chưa ghi đè.')
    temp=Path(p).with_name(Path(p).name+'.ca-vi.tmp')
    try:
        with temp.open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
        if (sha(p) if p.exists() else None)!=expected:raise RuntimeError('App đang ghi cache; thử lại sau.')
        os.replace(temp,p)
    finally:
        if temp.exists():temp.unlink()

def app_info(app):
    app=Path(app)
    choices=[app/'Contents/Info.plist',app/'Info.plist']
    choices += sorted((app/'Wrapper').glob('*.app/Info.plist'))
    choices += sorted((app/'Wrapper').glob('*.app/Contents/Info.plist'))
    metadata=next((p for p in choices if p.is_file()),None)
    if metadata is None:raise RuntimeError('Không tìm được Info.plist trong app đã chọn: '+str(app))
    with metadata.open('rb') as f:d=plistlib.load(f)
    name=str(d.get('CFBundleDisplayName',d.get('CFBundleName',Path(app).stem)))
    bundle=str(d.get('CFBundleIdentifier',''))
    normalized=lambda value:''.join(c for c in value.lower() if c.isalnum())
    if bundle.startswith('vn.hungle.') or 'viethoa' in normalized(app.stem) or 'việthóa' in normalized(name):raise RuntimeError('Đây là bộ Việt hóa; hãy chọn Complete Anatomy gốc.')
    if not any('completeanatomy' in normalized(value) for value in [name,app.stem,bundle]):raise RuntimeError('App được chọn không phải Complete Anatomy: '+name)
    if not d.get('CFBundleIdentifier'):raise RuntimeError('Không đọc được bundle identifier của app.')
    return {'path':str(app.resolve()),'bundle_id':bundle,'name':name,'version':d.get('CFBundleShortVersionString','unknown'),'metadata_path':str(metadata),'application_kind':'wrapped-ios' if 'Wrapper' in metadata.relative_to(app).parts else ('macos' if metadata.parent.name=='Contents' else 'ios-layout')}
def discover_apps(home=None):
    global LAST_DISCOVERED_APPS
    DISCOVERY_NOTES.clear()
    home=Path(home or Path.home());result=[]
    for parent in [Path('/Applications'),home/'Applications']:
        if not parent.is_dir():continue
        for directory,dirs,files in os.walk(parent,followlinks=False):
            p=Path(directory)
            for name in list(dirs):
                if name.endswith('.app'):
                    app=p/name
                    try:result.append(app_info(app))
                    except (OSError,ValueError,RuntimeError,plistlib.InvalidFileException) as e:
                        if 'anatom' in name.lower():DISCOVERY_NOTES.append({'path':str(app),'reason':str(e)})
                    dirs.remove(name)
            if len(p.relative_to(parent).parts)>=2:dirs[:]=[]
    LAST_DISCOVERED_APPS=result
    return result
def scan_engines(root,max_depth=6):
    root=Path(root);found=[]
    if not root.is_dir():return found
    for directory,dirs,files in os.walk(root,followlinks=False):
        p=Path(directory);depth=len(p.relative_to(root).parts)
        dirs[:]=[n for n in dirs if n not in {'model_assets','models','Uploads','EBWebView','node_modules','CacheStorage'} and not n.endswith('.app') and not (p/n).is_symlink()]
        if p.name=='Mobile3D4MEngine':
            if (p/'index.html').is_file() and (p/'Resources/dist/main.bundle.js').is_file():found.append(p)
            dirs[:]=[]
        elif depth>=max_depth:dirs[:]=[]
    return found
def discover_caches(info,home=None):
    home=Path(home or Path.home());library=home/'Library';bundle=info['bundle_id'];roots=[]
    containers=library/'Containers';containers_to_check=[]
    direct=containers/bundle
    if direct.is_dir():containers_to_check.append(direct)
    if containers.is_dir():
        for folder in containers.iterdir():
            if folder==direct or not folder.is_dir() or folder.is_symlink():continue
            try:
                with (folder/'.com.apple.containermanagerd.metadata.plist').open('rb') as f:metadata=plistlib.load(f)
                if metadata.get('MCMMetadataIdentifier')==bundle:containers_to_check.append(folder)
            except (OSError,ValueError,plistlib.InvalidFileException):pass
    for folder in containers_to_check:
        roots += [folder/'Data/Documents',folder/'Data/Library/Application Support',folder/'Data/Library/Caches']
    roots += [library/'Application Support'/bundle,library/'Application Support'/'Complete Anatomy',library/'Application Support'/'3D4Medical']
    return sorted(set(p for root in roots for p in scan_engines(root)),key=str)
def validate_cache(root,home=None):
    root=Path(root).expanduser();library=Path(home or Path.home())/'Library'
    if not root.resolve().is_relative_to(library.resolve()) or any(p.suffix=='.app' for p in [root,*root.parents]):raise RuntimeError('Chỉ chọn Mobile3D4MEngine trong Library của tài khoản hiện tại; không chọn bên trong app .app.')
    if root.name!='Mobile3D4MEngine' or not (root/'index.html').is_file() or not (root/'Resources/dist/main.bundle.js').is_file():raise RuntimeError('Chưa thấy cache Mobile3D4MEngine tương thích. Hãy mở Complete Anatomy một lần trước.')
    guarded(root/'index.html',root)
    return root.resolve()

class Installation:
    def __init__(self,root,state,assets=ASSETS):
        self.root=Path(root);self.state=Path(state);self.assets=Path(assets);self.index=self.root/'index.html';self.registry_path=self.state/'registry.json'
        self.report=read(self.assets/'MAC_ASSETS.json');self.stop=threading.Event();self.lock=threading.RLock();self.error='';self.removed=False
        if sha(self.assets/'bootstrap.template.js')!=self.report['bootstrap_template_sha256']:raise RuntimeError('Dữ liệu bản Mac sai mã băm.')
    def registry(self):
        d=read(self.registry_path)
        if d.get('format')!=1 or d.get('target')!=str(self.index.resolve()):raise RuntimeError('Đăng ký thuộc cache khác; không ghi đè.')
        if not re.fullmatch(r'ca-vi-macos-owned-[a-f0-9]{16}\.js',d.get('script_name','')) or not re.fullmatch(r'[a-f0-9]{64}',d.get('token','')) or type(d.get('port')) is not int or not 0<d['port']<65536:raise RuntimeError('Đăng ký bộ nạp Mac không hợp lệ.')
        if sha(self.state/'original.index.html')!=d['original_sha256']:raise RuntimeError('Bản sao trang gốc không khớp mã băm.')
        return d
    def prepare(self,port):
        guarded(self.index,self.root)
        from update_common import version
        highest=self.state/'highest_version.json'
        if highest.exists() and version(read(highest)['version'])>version(VERSION):raise RuntimeError('Đã dùng launcher Mac mới hơn; không nạp bản cũ.')
        if self.registry_path.exists():
            old=self.registry()
            if old.get('version')==VERSION and (not getattr(self,'license_snapshot',None) or old.get('display_expiry')==self.license_snapshot.get('expires')):return old
            if re.fullmatch(r'\d+\.\d+\.\d+',old.get('version','')) and version(old['version'])>version(VERSION):raise RuntimeError('Không nạp bản Mac cũ đè phiên bản mới.')
            if not re.fullmatch(r'\d+\.\d+\.\d+',old.get('version','')) and old.get('version') not in ('0.7.0-mac-test1','0.7.0-mac-test2'):raise RuntimeError('Không nhận diện phiên bản bộ nạp cũ; giữ bản sao để đối chiếu.')
            self.uninstall(reason='upgrade');self.stop.clear();self.removed=False
        original=self.index.read_bytes()
        if MARKER in original or b'ca-vi-owned-bootstrap' in original:raise RuntimeError('Trang đã có bản Việt hóa chưa đăng ký; chưa thay đổi. Hãy gửi báo cáo chẩn đoán.')
        if original.count(b'</body>')!=1 or b'<html' not in original.lower() or not (b'injectScript' in original or b'window.bridge' in original):raise RuntimeError('Trang Mac khác cấu trúc đã hỗ trợ; chỉ thu thập chẩn đoán, không ghi đè.')
        if b'Content-Security-Policy' in original:raise RuntimeError('Trang có chính sách script riêng; cần đối chiếu trước khi cài.')
        token=secrets.token_hex(32)
        template=(self.assets/'bootstrap.template.js').read_text(encoding='utf8')
        if getattr(self,'license_snapshot',None):template='window.__caViVerifiedLicense='+json.dumps({'version':VERSION,'valid':self.license_snapshot.get('valid') is True,'expires':self.license_snapshot.get('expires'),'device_bound':True},separators=(',',':'))+';\n'+template
        js=template.replace('__CAVI_MAC_TOKEN__',token).replace('__CAVI_MAC_PORT__',str(port)).encode()
        script_sha=hashlib.sha256(js).hexdigest();script_name='ca-vi-macos-owned-'+script_sha[:16]+'.js';script=self.root/script_name
        if script.exists():raise RuntimeError('Tệp bộ nạp đã tồn tại mà chưa đăng ký; không ghi đè.')
        tag=MARKER+b'<script defer src="'+script_name.encode()+b'"></script>\n'
        patched=original.replace(b'</body>',tag+b'</body>')
        self.state.mkdir(parents=True,exist_ok=True)
        atomic(self.state/'original.index.html',original,None,self.state)
        atomic(self.state/'patched.index.html',patched,None,self.state)
        atomic(self.state/'bootstrap.js',js,None,self.state)
        d={'format':1,'version':VERSION,'target':str(self.index.resolve()),'original_sha256':hashlib.sha256(original).hexdigest(),'patched_sha256':hashlib.sha256(patched).hexdigest(),'script_name':script_name,'script_sha256':script_sha,'token':token,'port':port,'created':time.time(),'display_expiry':getattr(self,'license_snapshot',{}).get('expires'),'main_sha256':sha(self.root/'Resources/dist/main.bundle.js')}
        save(self.registry_path,d);save(highest,{'version':VERSION,'cache_schema':1});return d
    def apply(self):
        with self.lock:
            d=self.registry();current=sha(self.index);script=self.root/d['script_name'];guarded(script,self.root)
            if d.get('main_sha256') and sha(self.root/'Resources/dist/main.bundle.js')!=d['main_sha256']:raise RuntimeError('Bundle Mac đã đổi; không nạp bản dịch vào bản chưa đối chiếu.')
            if current not in (d['original_sha256'],d['patched_sha256']):raise RuntimeError('Trang khởi tạo đã đổi phiên bản hoặc bị sửa; giữ nguyên app và bản sao.')
            existing=sha(script) if script.exists() else None
            if existing not in (None,d['script_sha256']):raise RuntimeError('Bộ nạp đã bị sửa; không ghi đè.')
            if sha(self.state/'bootstrap.js')!=d['script_sha256'] or sha(self.state/'patched.index.html')!=d['patched_sha256']:raise RuntimeError('Bản cài lưu không khớp mã băm.')
            if existing is None:atomic(script,(self.state/'bootstrap.js').read_bytes(),None,self.root)
            if current!=d['patched_sha256']:atomic(self.index,(self.state/'patched.index.html').read_bytes(),current,self.root)
            self.error=''
    def watch(self):
        seen=None
        while not self.stop.is_set():
            try:
                d=self.registry();st=self.index.stat();script=self.root/d['script_name'];ss=script.stat() if script.exists() else None;ms=(self.root/'Resources/dist/main.bundle.js').stat();stamp=(st.st_mtime_ns,st.st_size,ss.st_mtime_ns if ss else None,ms.st_size,ms.st_mtime_ns)
                if stamp!=seen:
                    if self.stop.wait(.04):return
                    self.apply();st=self.index.stat();ss=script.stat();seen=(st.st_mtime_ns,st.st_size,ss.st_mtime_ns,ms.st_size,ms.st_mtime_ns)
            except (OSError,ValueError,RuntimeError) as e:self.error=str(e)
            self.stop.wait(.2)
    def uninstall(self,reason='manual'):
        self.stop.set()
        try:
            with self.lock:
                d=self.registry();current=sha(self.index);script=self.root/d['script_name'];guarded(script,self.root)
                if current not in (d['original_sha256'],d['patched_sha256']):raise RuntimeError('Trang đã đổi; không gỡ mù. Giữ bản sao để đối chiếu.')
                if script.exists() and sha(script)!=d['script_sha256']:raise RuntimeError('Script đã đổi; không xóa mù.')
                if current!=d['original_sha256']:atomic(self.index,(self.state/'original.index.html').read_bytes(),current,self.root)
                if sha(self.index)!=d['original_sha256']:raise RuntimeError('Chưa xác minh khôi phục trang gốc.')
                if script.exists():script.unlink()
                receipt={'version':VERSION,'restored':True,'original_sha256':d['original_sha256'],'app_closed':False,'main_bundle_changed':False,'time':time.time(),'reason':reason}
                save(self.state/'uninstall_receipt.json',receipt)
                for name in ['registry.json','original.index.html','patched.index.html','bootstrap.js']:(self.state/name).unlink(missing_ok=True)
                self.removed=True;return receipt
        except Exception:self.stop.clear();raise

class Control:
    def __init__(self,item,auth=None):
        self.item=item;self.auth=auth;self.d=item.registry();self.ready=False;self.frontend={};self.finished=threading.Event();self.server=None;self.last_seen=0
    def start(self):
        owner=self
        class Handler(BaseHTTPRequestHandler):
            def log_message(self,*args):pass
            def origin(self):
                value=self.headers.get('Origin','');p=urlparse(value)
                return value if value in ('','null') or value.startswith('file://') or (p.scheme in ('http','https') and p.hostname in ('127.0.0.1','localhost')) else None
            def send_json(self,status,value):
                data=json.dumps(value,ensure_ascii=False).encode();self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(data)))
                origin=self.origin()
                if origin:self.send_header('Access-Control-Allow-Origin',origin)
                self.end_headers();self.wfile.write(data)
            def do_OPTIONS(self):
                if self.origin() is None:self.send_json(403,{'ok':False});return
                self.send_response(204);self.send_header('Access-Control-Allow-Origin',self.origin() or 'null');self.send_header('Access-Control-Allow-Headers','Content-Type, X-CAVi-Token');self.send_header('Access-Control-Allow-Methods','POST');self.send_header('Access-Control-Allow-Private-Network','true');self.send_header('Vary','Origin');self.end_headers()
            def do_GET(self):
                if self.path!='/diagnostic' or self.headers.get('X-CAVi-Token')!=owner.d['token']:self.send_json(403,{'ok':False});return
                self.send_json(200,{'ok':True,'version':VERSION,'frontend_ready':owner.ready,'frontend':owner.frontend,'error':owner.item.error})
            def do_POST(self):
                try:
                    length=int(self.headers.get('Content-Length','0'))
                    if not 0<length<4096:raise ValueError('Invalid size')
                    self.connection.settimeout(5)
                    body=self.rfile.read(length)
                    value=json.loads(body)
                    if not isinstance(value,dict):raise ValueError('Invalid request')
                    header=self.headers.get('X-CAVi-Token');provided=header if header is not None else value.get('token')
                    if self.path!='/command' or provided!=owner.d['token'] or (header is not None and 'token' in value and value['token']!=header) or self.origin() is None:self.send_json(403,{'ok':False});return
                    if value.get('version') not in (None,VERSION):raise ValueError('Menu version mismatch; reopen Shanatomy.')
                    owner.last_seen=time.monotonic();action=value.get('action')
                    if action not in ('license_status','ready','uninstall') and owner.auth and not owner.auth.snapshot().get('valid'):raise ValueError('Key không còn hợp lệ.')
                    if action=='ready':owner.ready=True;owner.frontend={k:value.get(k) for k in ('version','language','orb','panel','viewport','shadow')};self.send_json(200,{'ok':True})
                    elif action=='language' and value.get('language') in ('vi','en'):self.send_json(200,{'ok':True})
                    elif action=='license_status':
                        owner.ready=True;owner.frontend={k:value.get(k) for k in ('version','language','orb','panel','viewport','shadow')};self.send_json(200,{'ok':True,'license':owner.auth.snapshot() if owner.auth else {'valid':True}})
                    elif action=='open_contact':
                        chrome=Path('/Applications/Google Chrome.app')
                        subprocess.Popen(['/usr/bin/open',*(['-a',str(chrome)] if chrome.exists() else []),'https://zalo.me/0332120840']);self.send_json(200,{'ok':True})
                    elif action=='uninstall':receipt=owner.item.uninstall();owner.finished.set();self.send_json(200,{'ok':True,'receipt':receipt})
                    else:raise ValueError('Unknown action')
                except Exception as e:self.send_json(409,{'ok':False,'error':str(e)})
        self.server=ThreadingHTTPServer(('127.0.0.1',self.d['port']),Handler);self.server.daemon_threads=True
        threading.Thread(target=self.server.serve_forever,daemon=True).start()
    def close(self):
        if self.server:self.server.shutdown();self.server.server_close()

def dialog(message):
    if sys.platform!='darwin':print(message);return
    subprocess.run(['/usr/bin/osascript','-e','on run argv','-e','display dialog (item 1 of argv) with title "Việt hóa Complete Anatomy · Shanatomy Mac" buttons {"OK"} default button "OK"','-e','end run',message],check=False)
def choose_cache():
    result=subprocess.run(['/usr/bin/osascript','-e','POSIX path of (choose folder with prompt "Chọn thư mục Mobile3D4MEngine trong Library của Complete Anatomy")'],text=True,capture_output=True)
    if result.returncode:raise RuntimeError('Chưa chọn cache.')
    return Path(result.stdout.strip())
def choose_app():
    result=subprocess.run(['/usr/bin/osascript','-e','POSIX path of (choose file of type {"com.apple.application-bundle"} with prompt "Chọn Complete Anatomy gốc (.app), không chọn VietHoa Complete Anatomy Mac")'],text=True,capture_output=True)
    if result.returncode:raise RuntimeError('Bạn chưa chọn Complete Anatomy gốc. Chưa sửa app.')
    return Path(result.stdout.strip())
def confirm_uninstall():
    result=subprocess.run(['/usr/bin/osascript','-e','button returned of (display dialog "Khôi phục trang khởi tạo gốc và xóa script Việt hóa do bộ Mac này cài? Complete Anatomy và dữ liệu học sẽ giữ nguyên." with title "Gỡ Việt hóa Mac" buttons {"Hủy", "Gỡ"} default button "Hủy")'],text=True,capture_output=True)
    return result.returncode==0 and result.stdout.strip()=='Gỡ'
def write_diagnostic(state,info,caches,item=None,control=None,error=''):
    platform=__import__('platform')
    payload={'version':VERSION,'platform':sys.platform,'macos':platform.mac_ver()[0],'machine':platform.machine(),'python':sys.version.split()[0],'app':info,'apps_detected':LAST_DISCOVERED_APPS,'app_discovery_notes':DISCOVERY_NOTES,'cache_candidates':[str(p) for p in caches],'error':error,'main_bundle_modified_by_tool':False,'frontend_ready':bool(control and control.ready)}
    if item and item.index.exists():
        main=item.root/'Resources/dist/main.bundle.js';st=main.stat();stamp=(st.st_size,st.st_mtime_ns)
        if getattr(item,'main_stamp',None)!=stamp:item.main_stamp=stamp;item.main_sha=sha(main)
        payload.update(index_sha256=sha(item.index),cache=str(item.root),main_bundle_sha256=item.main_sha)
    if control:payload['frontend']=control.frontend
    save(state/'CHAN_DOAN_MAC.json',payload)
    return state/'CHAN_DOAN_MAC.json'
def main(argv=None):
    if '--self-test' in sys.argv:
        import tkinter as tk
        from mac_updater import bundle_kind
        report=read(ASSETS/'MAC_ASSETS.json')
        if sha(ASSETS/'bootstrap.template.js')!=report['bootstrap_template_sha256']:raise RuntimeError('Asset hash mismatch')
        result={'version':VERSION,'assets_verified':True,'tcl_version':tk.Tcl().eval('info patchlevel'),'frozen':bool(getattr(sys,'frozen',False)),'architecture':__import__('platform').machine(),'app_opened':False,'cache_changed':False}
        if '--self-test-report' in sys.argv:save(Path(sys.argv[sys.argv.index('--self-test-report')+1]),result)
        print(json.dumps(result));return
    if '--apply-update' in sys.argv:
        from mac_updater import helper
        i=sys.argv.index('--apply-update');helper(Path(sys.argv[i+1]),ASSETS/'update_public_key.json',int(sys.argv[i+2]));return
    parser=argparse.ArgumentParser();parser.add_argument('--app');parser.add_argument('--cache');parser.add_argument('--diagnose',action='store_true');parser.add_argument('--uninstall',action='store_true');parser.add_argument('--gui',action='store_true');parser.add_argument('--update-recovery',action='store_true');args=parser.parse_args(argv)
    args.gui=args.gui or bool(getattr(sys,'frozen',False))
    if sys.platform!='darwin':raise RuntimeError('Bản này dành cho macOS; không cài lên Windows.')
    if args.uninstall and args.gui and not confirm_uninstall():return
    state=Path.home()/'Library/Application Support/HungLe/CompleteAnatomyVietnameseMac';state.mkdir(parents=True,exist_ok=True)
    import fcntl
    lock=(state/'launcher.lock').open('a')
    try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:
        lock.close()
        if args.diagnose:
            import urllib.request
            from types import SimpleNamespace
            try:
                d=read(state/'registry.json');item=Installation(Path(d['target']).parent,state)
                request=urllib.request.Request('http://127.0.0.1:'+str(d['port'])+'/diagnostic',headers={'X-CAVi-Token':d['token']})
                with urllib.request.urlopen(request,timeout=5) as response:value=json.loads(response.read())
                control=SimpleNamespace(ready=value['frontend_ready'],frontend=value['frontend'])
                apps=discover_apps();info=apps[0] if len(apps)==1 else None
                path=write_diagnostic(state,info,[item.root],item,control,value.get('error',''))
                dialog('Đã ghi chẩn đoán từ bộ đang chạy:\n'+str(path));subprocess.run(['/usr/bin/open','-R',str(path)],check=False)
            except Exception as e:dialog('Chưa đọc được chẩn đoán đang chạy: '+str(e))
            return
        if args.uninstall:
            import urllib.request
            d=read(state/'registry.json')
            request=urllib.request.Request('http://127.0.0.1:'+str(d['port'])+'/command',data=b'{"action":"uninstall"}',headers={'Content-Type':'application/json','X-CAVi-Token':d['token']})
            try:
                with urllib.request.urlopen(request,timeout=20) as response:receipt=json.loads(response.read())
                if not receipt.get('ok'):raise RuntimeError(receipt.get('error','Chưa gỡ được'))
                dialog('Đã khôi phục bản gốc và xóa bộ nạp Mac. Complete Anatomy vẫn mở. Bạn tự mở lại app để hết menu trong phiên cũ.')
            except Exception as e:dialog('Chưa gỡ được: '+str(e)+'\nHãy dùng nút Gỡ trong menu hoặc tự đóng bộ khởi chạy rồi chạy Gỡ riêng.')
            return
        dialog('Bộ Việt hóa Mac đang chạy. Không mở thêm bộ thứ hai. Nếu là bản cũ, hãy dừng riêng launcher cũ trước khi dùng bản mới.');return
    except Exception:lock.close();raise
    info=None;caches=[];item=None;control=None;auth=None;tkroot=None;session_owned=False
    try:
        if args.app:info=app_info(args.app)
        else:
            selection=state/'selected_app.json'
            if selection.exists():
                try:info=app_info(read(selection)['path'])
                except (OSError,ValueError,RuntimeError,KeyError):pass
            if info is None:
                apps=discover_apps()
                if len(apps)==1:info=apps[0]
                elif args.gui and not args.diagnose:info=app_info(choose_app())
                elif not args.diagnose:raise RuntimeError('Chưa xác định được app gốc. Chạy BAT_VIET_HOA_MAC.command để chọn trong Finder hoặc dùng --app.')
        if info:
            save(state/'selected_app.json',{'path':info['path']})
            if args.cache and not args.diagnose:caches=[validate_cache(args.cache)]
            elif not args.diagnose:
                caches=[]
                try:
                    if (state/'registry.json').exists():caches=[validate_cache(Path(read(state/'registry.json')['target']).parent)]
                    elif (state/'selected_cache.json').exists():
                        selected=read(state/'selected_cache.json')
                        if selected.get('app')==info['path']:caches=[validate_cache(selected['cache'])]
                except (OSError,ValueError,RuntimeError,KeyError):caches=[]
                if not caches:caches=discover_caches(info)
            else:caches=discover_caches(info)
        if args.diagnose:
            if (state/'registry.json').exists():
                d=read(state/'registry.json');item=Installation(Path(d['target']).parent,state)
            path=write_diagnostic(state,info,caches,item)
            dialog('Đã tạo chẩn đoán, không sửa app:\n'+str(path));subprocess.run(['/usr/bin/open','-R',str(path)],check=False);return
        if not args.uninstall:
            from license_auth import activation_dialog
            import tkinter as tk
            from mac_updater import Updater
            tkroot=tk.Tk();tkroot.withdraw()
            target=Path(sys.executable).resolve().parents[2] if getattr(sys,'frozen',False) else Path(__file__).resolve().parents[2]
            def preflight(client,notify,cancelled):
                client.updater=Updater(state,ASSETS,VERSION,target)
                if args.update_recovery:
                    client.updater.pending=None
                    notify({'state':'current','message':'Cập nhật chưa hoàn tất. Đang mở bản được khôi phục.'});return 'continue'
                try:return client.updater.prepare(notify,cancelled)
                except Exception as e:
                    from license_auth import UpdateUnavailable
                    raise UpdateUnavailable('Chưa cập nhật được. Bạn có thể dùng bản hiện tại.') from e
            auth=activation_dialog(tkroot,state,after_auth=preflight)
            if auth is None:return
            if not auth.snapshot()['valid']:raise RuntimeError('Key đã hết hạn. Vui lòng xác thực lại.')
            if getattr(auth,'restart_requested',False) or getattr(getattr(auth,'updater',None),'pending',None):
                auth.updater.schedule();return
            tkroot.destroy();tkroot=None
        if (state/'registry.json').exists():root=validate_cache(Path(read(state/'registry.json')['target']).parent)
        elif args.cache:root=validate_cache(args.cache)
        elif len(caches)==1:root=validate_cache(caches[0])
        elif args.gui:root=validate_cache(choose_cache())
        else:raise RuntimeError('Chưa thấy một cache phù hợp. Mở Complete Anatomy một lần rồi chạy lại; dùng --cache nếu cần chọn thủ công.')
        save(state/'selected_cache.json',{'app':info['path'],'cache':str(root)})
        item=Installation(root,state)
        if args.uninstall:
            if not item.registry_path.exists():dialog('Chưa có bản Mac do bộ này cài.');return
            item.uninstall();dialog('Đã khôi phục trang gốc và xóa script Việt hóa của bộ Mac. Không đóng Complete Anatomy.');return
        item.license_snapshot=auth.snapshot();item.prepare(18768);session_owned=True;control=Control(item,auth);control.start();item.apply()
        threading.Thread(target=item.watch,daemon=True).start()
        from mac_lifecycle import SessionCleaner,app_running
        cleaner=SessionCleaner(item,lambda:app_running(info['bundle_id']))
        subprocess.run(['/usr/bin/open',info['path']],check=True,timeout=8,capture_output=True)
        warned=False;started=time.monotonic();auth_next=started+300;worker=None;revoked=False;restored_at=None;last_diagnostic=0
        while not control.finished.wait(1):
            now=time.monotonic()
            if not revoked and not auth.snapshot()['valid']:revoked=True;item.stop.set()
            if revoked:
                if restored_at is None:
                    try:item.uninstall(reason='license_invalid');restored_at=now
                    except Exception as e:save(state/'cleanup_error.json',{'error':str(e),'backup_retained':True})
                if restored_at is not None and now-restored_at>=70:break
            else:
                cleaner.tick()
                if cleaner.done:break
                if now>=auth_next and (worker is None or not worker.is_alive()):
                    def refresh():
                        try:auth.refresh()
                        except Exception:auth.valid=False
                    worker=threading.Thread(target=refresh,daemon=True);worker.start();auth_next=now+300
            if now-last_diagnostic>=5:write_diagnostic(state,info,caches,item,control,item.error or cleaner.error);last_diagnostic=now
            if not revoked and not warned and not control.ready and now-started>60:
                warned=True;write_diagnostic(state,info,caches,item,control,'Chưa nhận tín hiệu menu; giữ bộ khởi chạy khi Complete Anatomy còn mở.')
    except KeyboardInterrupt:pass
    except Exception as e:
        path=write_diagnostic(state,info,caches,item,control,str(e))
        if not session_owned:dialog(str(e)+'\n\nChẩn đoán: '+str(path))
        if not args.gui:raise
    finally:
        if item:item.stop.set()
        if session_owned and item and not item.removed and item.registry_path.exists():
            try:item.uninstall(reason='launcher_exit')
            except Exception as e:save(state/'cleanup_error.json',{'error':str(e),'backup_retained':True})
        if control:control.close()
        if tkroot:tkroot.destroy()
        fcntl.flock(lock,fcntl.LOCK_UN);lock.close()
if __name__=='__main__':main()
