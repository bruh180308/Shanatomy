"""Signed, separate macOS assets on the same GitHub release as Windows."""
import base64,hashlib,json,os,plistlib,re,shutil,stat,subprocess,sys,time,zipfile
from pathlib import Path,PurePosixPath
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from update_common import canonical,digest,repository,allowed_url,fetch,atomic_json as write_json,version
IDENTIFIER='vn.hungle.shanatomy.mac';APP_NAME='Shanatomy Mac.app';ZIP_ROOT='Shanatomy-MacOS'
MAX_ZIP=200*1024*1024;MAX_EXPANDED=300*1024*1024

def safe_path(path):
    path=Path(path).absolute()
    if any(p.is_symlink() for p in [path,*path.parents]):raise ValueError('Đường dẫn cập nhật có liên kết; chưa ghi đè.')
    return path

def atomic_json(path,value):
    path=safe_path(path);safe_path(path.with_suffix('.tmp'));write_json(path,value)

def verify_macos(envelope,key,repo,native=False):
    p=envelope['payload']
    Ed25519PublicKey.from_public_bytes(base64.b64decode(key,validate=True)).verify(base64.b64decode(envelope['signature'],validate=True),canonical(p))
    version(p['version'])
    native_variant=native and isinstance(p.get('native_asset'),dict)
    if native_variant:p={**p,'asset':p['native_asset'],'package_kind':'self-contained-app'}
    if p.get('schema')!=1 or p.get('platform')!='macos-apple-silicon' or p.get('cache_schema')!=1:raise ValueError('Gói cập nhật không dành cho Mac này.')
    if p.get('package_kind') not in ('python-shell-app','self-contained-app'):raise ValueError('Kiểu gói Mac không hợp lệ.')
    if native and p['package_kind']!='self-contained-app':raise ValueError('Bản tự chứa cần gói cập nhật Mac tự chứa. Bản hiện tại được giữ lại.')
    fmt=p.get('package_format','zip')
    if fmt not in ('zip','dmg') or (fmt=='dmg' and p['package_kind']!='self-contained-app'):raise ValueError('Định dạng gói Mac không hợp lệ.')
    a=p['asset'];url=allowed_url(a['url']);from urllib.parse import urlparse
    u=urlparse(url)
    if u.hostname!='github.com' or not u.path.startswith('/'+repository(repo)+'/releases/download/') or not u.path.endswith('/Shanatomy-MacOS.dmg' if fmt=='dmg' else ('/Shanatomy-MacOS-Native.zip' if native_variant else '/Shanatomy-MacOS.zip')) or u.query or u.fragment:raise ValueError('Gói Mac không thuộc kho đã chọn.')
    if type(a['size']) is not int or not 0<a['size']<=MAX_ZIP or not re.fullmatch(r'[a-f0-9]{64}',a['sha256']):raise ValueError('Thông tin tải Mac không hợp lệ.')
    if len(str(p.get('notes','')))>8000:raise ValueError('Ghi chú cập nhật quá dài.')
    return p

def validate_bundle(app):
    app=Path(app)
    if not app.is_absolute() or app.suffix!='.app' or any(p.is_symlink() for p in [app,*app.parents]):raise ValueError('Đường dẫn Shanatomy không hợp lệ.')
    if not (app/'Contents/Info.plist').is_file():raise ValueError('Thiếu Info.plist của Shanatomy Mac.')
    with (app/'Contents/Info.plist').open('rb') as f:info=plistlib.load(f)
    if info.get('CFBundleIdentifier')!=IDENTIFIER:raise ValueError('Chỉ cập nhật bộ Shanatomy Mac, không thay app khác.')
    executable=info.get('CFBundleExecutable','')
    if not re.fullmatch(r'[A-Za-z0-9_.-]+',executable) or not (app/'Contents/MacOS'/executable).is_file():raise ValueError('Thiếu bộ khởi chạy Mac.')
    return app

def bundle_hash(app):
    app=validate_bundle(app);h=hashlib.sha256()
    for p in sorted(app.rglob('*')):
        if p.is_symlink():raise ValueError('Bundle có liên kết chưa hỗ trợ.')
        if p.is_file():h.update(p.relative_to(app).as_posix().encode()+b'\0'+bytes.fromhex(digest(p)))
    return h.hexdigest()

def bundle_kind(app):
    app=validate_bundle(app)
    with (app/'Contents/Info.plist').open('rb') as f:name=plistlib.load(f)['CFBundleExecutable']
    with (app/'Contents/MacOS'/name).open('rb') as f:magic=f.read(4)
    if magic[:2]==b'#!':return 'python-shell-app'
    if magic in (b'\xcf\xfa\xed\xfe',b'\xfe\xed\xfa\xcf',b'\xca\xfe\xba\xbe',b'\xbe\xba\xfe\xca'):return 'self-contained-app'
    raise ValueError('Bộ khởi chạy không phải shell hoặc Mach-O được hỗ trợ.')

def extract_app(archive,destination):
    """Only regular files; reject traversal, duplicates and archive bombs."""
    destination=Path(destination)
    if destination.exists():raise ValueError('Thư mục dựng cập nhật đã tồn tại; chưa ghi đè.')
    prefix=ZIP_ROOT+'/'+APP_NAME+'/'
    with zipfile.ZipFile(archive) as z:
        infos=z.infolist();names=set();total=0
        if len(infos)>3000:raise ValueError('Gói cập nhật quá nhiều tệp.')
        for i in infos:
            name=i.filename;p=PurePosixPath(name);kind=stat.S_IFMT(i.external_attr>>16)
            if not name or '\\' in name or ':' in name or '\0' in name or p.is_absolute() or '..' in p.parts or name in names or kind not in (0,stat.S_IFREG,stat.S_IFDIR):raise ValueError('Gói cập nhật chứa đường dẫn không an toàn.')
            names.add(name);total+=i.file_size
            if total>MAX_EXPANDED:raise ValueError('Gói giải nén vượt giới hạn.')
        destination.mkdir(parents=True)
        try:
            for i in infos:
                if not i.filename.startswith(prefix) or i.is_dir():continue
                rel=PurePosixPath(i.filename[len(prefix):]);p=destination/Path(*rel.parts);p.parent.mkdir(parents=True,exist_ok=True)
                with z.open(i) as source,p.open('xb') as out:shutil.copyfileobj(source,out)
                p.chmod(0o755 if rel.parts[:2]==('Contents','MacOS') else 0o644)
            validate_bundle(destination)
            external=ZIP_ROOT+'/MAC_PACKAGE_MANIFEST.json'
            outside=external in names
            records=json.loads(z.read(external) if outside else (destination/'Contents/Resources/MAC_PACKAGE_MANIFEST.json').read_text(encoding='utf8'))
            actual={p.relative_to(destination).as_posix() for p in destination.rglob('*') if p.is_file()}
            actual.discard('Contents/_CodeSignature/CodeResources')
            if actual!=set(records)|(set() if outside else {'Contents/Resources/MAC_PACKAGE_MANIFEST.json'}):raise ValueError('Danh mục gói Mac không khớp.')
            for rel,h in records.items():
                p=PurePosixPath(rel)
                if p.is_absolute() or '..' in p.parts or '\\' in rel or digest(destination/Path(*p.parts))!=h:raise ValueError('Mã băm nội dung Mac không khớp.')
        except Exception:
            shutil.rmtree(destination);raise
    return destination

def extract_dmg(archive,destination):
    """Mount verified disk image read-only; copy only the manifest-checked owned app."""
    destination=safe_path(destination)
    if destination.exists():raise ValueError('Thư mục cập nhật đã tồn tại.')
    mount=safe_path(destination.with_name(destination.name+'.mount'))
    if mount.exists():raise ValueError('Điểm gắn cập nhật đã tồn tại.')
    mount.mkdir(parents=True)
    attached=False
    try:
        subprocess.run(['/usr/bin/hdiutil','attach','-readonly','-nobrowse','-noautoopen','-mountpoint',str(mount),str(Path(archive).absolute())],check=True,timeout=30,capture_output=True)
        attached=True
        source=validate_bundle(mount/APP_NAME)
        record_path=mount/'MAC_PACKAGE_MANIFEST.json'
        if record_path.is_symlink() or record_path.stat().st_size>1024*1024:raise ValueError('Danh mục DMG không hợp lệ.')
        records=json.loads(record_path.read_text(encoding='utf8'))
        if not isinstance(records,dict) or len(records)>3000:raise ValueError('Danh mục DMG không hợp lệ.')
        actual=set();total=0
        for file in source.rglob('*'):
            if file.is_symlink() or (not file.is_file() and not file.is_dir()):raise ValueError('Bundle DMG có liên kết hoặc tệp đặc biệt.')
            if file.is_file():
                actual.add(file.relative_to(source).as_posix());total+=file.stat().st_size
                if total>MAX_EXPANDED:raise ValueError('Bundle DMG vượt giới hạn.')
        actual.discard('Contents/_CodeSignature/CodeResources')
        if actual!=set(records):raise ValueError('Danh mục DMG không khớp bundle.')
        for rel,h in records.items():
            path=PurePosixPath(rel)
            if path.is_absolute() or '..' in path.parts or '\\' in rel or not re.fullmatch(r'[a-f0-9]{64}',h):raise ValueError('Danh mục DMG có đường dẫn không an toàn.')
            if digest(source/Path(*path.parts))!=h:raise ValueError('Mã băm bundle DMG không khớp.')
        subprocess.run(['/usr/bin/codesign','--verify','--deep','--strict',str(source)],check=True,timeout=20,capture_output=True)
        shutil.copytree(source,destination)
        if bundle_hash(source)!=bundle_hash(destination):raise ValueError('Bundle sao chép không khớp.')
        return destination
    except Exception:
        if destination.exists():shutil.rmtree(destination)
        raise
    finally:
        if attached:
            # Never remove a mounted volume recursively; retain it if detach fails.
            subprocess.run(['/usr/bin/hdiutil','detach',str(mount)],check=True,timeout=20,capture_output=True)
        mount.rmdir()

def extract_package(archive,destination,payload):
    return extract_dmg(archive,destination) if payload.get('package_format')=='dmg' else extract_app(archive,destination)

class Updater:
    def __init__(self,state,assets,current,target,fetcher=fetch,native=None):
        self.state=safe_path(state);self.assets=Path(assets);self.current=current;self.target=validate_bundle(Path(target).absolute());self.fetcher=fetcher;self.native=bool(getattr(sys,'frozen',False)) if native is None else native;self.repo='bruh180308/Shanatomy';self.pending=None
        self.key=json.loads((self.assets/'update_public_key.json').read_text(encoding='utf-8-sig'))['ed25519']
        self.blocked_sha=''
        try:self.blocked_sha=json.loads((self.state/'updates/apply_error.json').read_text(encoding='utf-8-sig')).get('attempted_sha256','')
        except (OSError,ValueError):pass
        try:self.repo=repository(json.loads((self.state/'update_config.json').read_text(encoding='utf-8-sig'))['repository'])
        except (OSError,ValueError,KeyError):pass
        self.folder=safe_path(self.state/'updates');self.status={'state':'idle','current_version':current,'repository':self.repo};self.notify=lambda value:None
        try:
            record=json.loads((self.folder/'pending.json').read_text(encoding='utf-8-sig'));p=verify_macos(record['envelope'],self.key,self.repo,self.native)
            if version(p['version'])>version(current) and record['target']==str(self.target) and record['old_sha256']==bundle_hash(self.target) and digest(self.folder/'ready.zip')==p['asset']['sha256'] and p['asset']['sha256']!=self.blocked_sha:self.pending=record
        except Exception:pass
    def set(self,**values):self.status.update(values);self.notify(dict(self.status))
    def prepare(self,notify=lambda value:None,cancelled=lambda:False):
        self.notify=notify
        if cancelled():return 'cancelled'
        if self.pending:self.set(state='staged',progress=100,message='Bản Mac mới đã sẵn sàng.');return 'restart'
        self.set(state='checking',message='Đang kiểm tra bản mới…')
        envelope=json.loads(self.fetcher('https://github.com/'+self.repo+'/releases/latest/download/update-macos.json',128*1024));p=verify_macos(envelope,self.key,self.repo,self.native)
        if version(p['version'])<=version(self.current):self.set(state='current',message='Bạn đang dùng bản mới nhất.');return 'continue'
        if p['asset']['sha256']==self.blocked_sha:raise ValueError('Gói Mac này đã cài lỗi. Hãy mở bản mới thủ công; không lặp cập nhật.')
        if cancelled():return 'cancelled'
        safe_path(self.folder);self.folder.mkdir(parents=True,exist_ok=True);part=safe_path(self.folder/'download.part');ready=safe_path(self.folder/'ready.zip');safe_path(self.folder/'pending.json');safe_path(self.folder/'pending.json.tmp');a=p['asset']
        self.set(state='downloading',message='Đang tải bản Mac mới…',progress=0)
        try:
            def progress(n):
                if cancelled():raise InterruptedError('Đã hủy tải.')
                self.set(progress=min(100,round(n*100/a['size'])))
            size=self.fetcher(a['url'],a['size'],part,progress)
            if size!=a['size'] or digest(part)!=a['sha256']:raise ValueError('Mã băm gói Mac không khớp.')
            if cancelled():return 'cancelled'
            preview=self.folder/'validate-new.app'
            if preview.exists():raise ValueError('Còn thư mục cập nhật trước chưa dọn; chưa ghi đè.')
            extract_package(part,preview,p)
            try:
                with (preview/'Contents/Info.plist').open('rb') as f:info=plistlib.load(f)
                if info.get('CFBundleShortVersionString')!=p['version']:raise ValueError('Phiên bản bên trong gói Mac không khớp.')
                if bundle_kind(preview)!=p['package_kind']:raise ValueError('Kiểu bundle Mac không khớp metadata.')
            finally:shutil.rmtree(preview)
            if cancelled():return 'cancelled'
            os.replace(part,ready)
            record={'envelope':envelope,'repository':self.repo,'target':str(self.target),'old_sha256':bundle_hash(self.target),'current_version':self.current,'native':self.native,'restart':True}
            atomic_json(self.folder/'pending.json',record);self.pending=record
            self.set(state='staged',progress=100,message='Đã xác minh. Đang khởi động lại Shanatomy…');return 'restart'
        finally:part.unlink(missing_ok=True)
    def schedule(self):
        if not self.pending:raise ValueError('Chưa có bản cập nhật đã xác minh.')
        safe_path(self.folder)
        receipt=safe_path(self.folder/'helper_files.json')
        previous={}
        if receipt.exists():previous=json.loads(receipt.read_text(encoding='utf8'))
        if self.native:
            helper=safe_path(self.folder/'apply-helper.app')
            if helper.exists():
                if bundle_hash(helper)!=previous.get('apply-helper.app'):raise ValueError('Bộ cập nhật trước đã thay đổi; không xóa.')
                shutil.rmtree(helper)
            shutil.copytree(self.target,helper)
            atomic_json(receipt,{'apply-helper.app':bundle_hash(helper)})
            with (helper/'Contents/Info.plist').open('rb') as f:name=plistlib.load(f)['CFBundleExecutable']
            env={k:v for k,v in os.environ.items() if not k.startswith('_PYI_') and k not in ('TCL_LIBRARY','TK_LIBRARY','_MEIPASS2')};env['PYINSTALLER_RESET_ENVIRONMENT']='1'
            subprocess.Popen([str(helper/'Contents/MacOS'/name),'--apply-update',str(self.state),str(os.getpid())],env=env,cwd=str(self.folder),start_new_session=True)
        else:
            sources={name:Path(__file__).with_name(name) for name in ('mac_updater.py','update_common.py')}
            sources['update_public_key.json']=self.assets/'update_public_key.json'
            for name in sources:
                dest=safe_path(self.folder/name)
                if dest.exists() and digest(dest)!=previous.get(name):raise ValueError('Tệp bộ cập nhật trước đã thay đổi; không ghi đè.')
            for name,source in sources.items():shutil.copy2(source,self.folder/name)
            atomic_json(receipt,{name:digest(self.folder/name) for name in sources})
            subprocess.Popen([sys.executable,str(self.folder/'mac_updater.py'),'--apply',str(self.state),str(os.getpid())],start_new_session=True)

def wait_parent(pid,timeout=90):
    if pid<=1:raise ValueError('PID không hợp lệ.')
    start=time.monotonic()
    while True:
        try:os.kill(pid,0)
        except ProcessLookupError:return
        if time.monotonic()-start>timeout:raise ValueError('Bộ khởi chạy cũ chưa thoát; không tự đóng tiến trình.')
        time.sleep(.2)

def relaunch(app):
    # open may start successfully yet reject the bundle; observe its exit code.
    subprocess.run(['/usr/bin/open','-n',str(app)],check=True,timeout=20,capture_output=True)

def apply_pending(state,keyfile,pid,waiter=wait_parent,launch=relaunch):
    folder=safe_path(Path(state)/'updates');r=json.loads(safe_path(folder/'pending.json').read_text(encoding='utf-8-sig'));key=json.loads(Path(keyfile).read_text(encoding='utf-8-sig'))['ed25519'];p=verify_macos(r['envelope'],key,r['repository'],r.get('native',False));target=validate_bundle(Path(r['target']))
    if version(p['version'])<=version(r['current_version']):raise ValueError('Không hạ phiên bản Mac.')
    waiter(pid)
    if bundle_hash(target)!=r['old_sha256'] or digest(folder/'ready.zip')!=p['asset']['sha256']:raise ValueError('Tệp cập nhật đã thay đổi.')
    incoming=target.with_name(target.stem+'.incoming.app');backup=target.with_name(target.stem+'.previous.app')
    extract_package(folder/'ready.zip',incoming,p)
    try:
        with (incoming/'Contents/Info.plist').open('rb') as f:info=plistlib.load(f)
        if info.get('CFBundleShortVersionString')!=p['version']:raise ValueError('Phiên bản gói Mac không khớp.')
        if bundle_kind(incoming)!=p['package_kind']:raise ValueError('Kiểu bundle Mac không khớp metadata.')
        newhash=bundle_hash(incoming)
        if bundle_hash(target)!=r['old_sha256']:raise ValueError('Bundle cũ vừa thay đổi.')
        if backup.exists():
            last=json.loads((folder/'last_update.json').read_text(encoding='utf-8-sig'))
            if bundle_hash(backup)!=last['backup_sha256']:raise ValueError('Bản dự phòng đã thay đổi; không xóa.')
            shutil.rmtree(backup)
        os.replace(target,backup)
        try:
            os.replace(incoming,target)
            if bundle_hash(target)!=newhash:raise ValueError('Bundle đã cài không khớp.')
        except Exception:
            if target.exists():validate_bundle(target);shutil.rmtree(target)
            os.replace(backup,target);raise
        try:
            atomic_json(folder/'last_update.json',{'version':p['version'],'sha256':newhash,'backup_sha256':r['old_sha256'],'backup':str(backup)})
        except OSError:pass
        launch(target)
        try:(folder/'pending.json').unlink();(folder/'ready.zip').unlink()
        except OSError:pass
    finally:
        if incoming.exists():validate_bundle(incoming);shutil.rmtree(incoming)

def helper(state,keyfile,pid):
    folder=Path(state)/'updates'
    try:record=json.loads((folder/'pending.json').read_text(encoding='utf-8-sig'))
    except Exception:record=None
    try:apply_pending(state,keyfile,pid)
    except Exception as e:
        folder=Path(state)/'updates';atomic_json(folder/'apply_error.json',{'error':str(e),'backup_retained':True,'attempted_sha256':(record or {}).get('envelope',{}).get('payload',{}).get('asset',{}).get('sha256','')})
        try:
            r=record;target=validate_bundle(Path(r['target']));p=verify_macos(r['envelope'],json.loads(Path(keyfile).read_text(encoding='utf-8-sig'))['ed25519'],r['repository'],r.get('native',False))
            if bundle_hash(target)==r['old_sha256']:
                subprocess.Popen(['/usr/bin/open','-n',str(target),'--args','--update-recovery'],start_new_session=True)
            elif digest(folder/'ready.zip')==p['asset']['sha256']:
                preview=folder/'recovery-verify.app';extract_package(folder/'ready.zip',preview,p)
                try:
                    if bundle_hash(preview)==bundle_hash(target):relaunch(target)
                finally:shutil.rmtree(preview)
        except Exception:pass

if __name__=='__main__':
    if len(sys.argv)==4 and sys.argv[1]=='--apply':helper(Path(sys.argv[2]),Path(__file__).with_name('update_public_key.json'),int(sys.argv[3]))
