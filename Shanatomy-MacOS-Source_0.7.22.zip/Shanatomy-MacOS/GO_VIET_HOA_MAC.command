#!/bin/bash
set -e
CAVI_ROOT="$(cd -- "$(dirname -- "$0")" && pwd)"
exec /bin/bash "$CAVI_ROOT/Shanatomy Mac.app/Contents/MacOS/ShanatomyMac" --uninstall
