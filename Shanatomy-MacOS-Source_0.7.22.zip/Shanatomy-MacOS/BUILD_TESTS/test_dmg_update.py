import json,shutil,unittest
from pathlib import Path
from unittest.mock import patch
import test_updater_mac as fixtures
make_app=fixtures.make_app
from mac_updater import *

class DmgTests(unittest.TestCase):
    setUp=fixtures.UpdateMacTests.setUp
    sign=fixtures.UpdateMacTests.sign
    def test_signed_dmg_format_and_url(self):
        self.payload.update(package_kind='self-contained-app',package_format='dmg')
        self.payload['asset']['url']=self.payload['asset']['url'].replace('.zip','.dmg');self.sign()
        self.assertEqual(verify_macos(self.envelope,self.pub,'bruh180308/Shanatomy',True)['package_format'],'dmg')
        self.payload['package_format']='exe';self.sign()
        with self.assertRaises(ValueError):verify_macos(self.envelope,self.pub,'bruh180308/Shanatomy',True)
    def fixture(self,mount):
        app=make_app(mount/APP_NAME)
        (app/'Contents/Resources/MAC_PACKAGE_MANIFEST.json').unlink()
        (mount/'MAC_PACKAGE_MANIFEST.json').write_text(json.dumps({p.relative_to(app).as_posix():digest(p) for p in app.rglob('*') if p.is_file()}))
    def run_mount(self,args,**kwargs):
        if args[1]=='attach':self.fixture(Path(args[args.index('-mountpoint')+1]))
        elif args[1]=='detach':shutil.rmtree(args[-1]);Path(args[-1]).mkdir()
    def test_dmg_readonly_verify_copy_and_detach(self):
        destination=self.root/'incoming.app'
        with patch('mac_updater.subprocess.run',side_effect=self.run_mount) as run:
            extract_dmg(self.zip,destination)
            self.assertTrue(destination.is_dir());self.assertIn('-readonly',run.call_args_list[0].args[0])
            self.assertTrue(any(x.args[0][0]=='/usr/bin/codesign' for x in run.call_args_list))
        self.assertFalse(destination.with_name(destination.name+'.mount').exists())
    def test_bad_manifest_cleans_destination_and_detaches(self):
        def bad(args,**kwargs):
            self.run_mount(args,**kwargs)
            if args[1]=='attach':(Path(args[args.index('-mountpoint')+1])/'MAC_PACKAGE_MANIFEST.json').write_text('{}')
        dest=self.root/'bad.app'
        with patch('mac_updater.subprocess.run',side_effect=bad) as run:
            with self.assertRaises(ValueError):extract_dmg(self.zip,dest)
            self.assertEqual(run.call_args.args[0][1],'detach')
        self.assertFalse(dest.exists())
