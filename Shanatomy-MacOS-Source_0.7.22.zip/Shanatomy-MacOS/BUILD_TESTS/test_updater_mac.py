import base64,hashlib,json,plistlib,tempfile,unittest,zipfile,stat
from pathlib import Path
from unittest.mock import Mock,patch
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization
from mac_updater import *
from package_native import manifest,zip_app

def make_app(app,ver='0.7.22'):
    (app/'Contents/MacOS').mkdir(parents=True);(app/'Contents/Resources/assets').mkdir(parents=True)
    with (app/'Contents/Info.plist').open('wb') as f:plistlib.dump({'CFBundleIdentifier':IDENTIFIER,'CFBundleExecutable':'ShanatomyMac','CFBundleShortVersionString':ver},f)
    (app/'Contents/MacOS/ShanatomyMac').write_bytes(b'#!/bin/bash\necho source\n');(app/'Contents/Resources/assets/data').write_bytes(b'medical-data-unchanged');manifest(app)
    return app

class UpdateMacTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.root=Path(self.temp.name);self.app=make_app(self.root/'Shanatomy Mac.app','0.7.10');self.new=make_app(self.root/'new.app');self.zip=self.root/'new.zip';zip_app(self.new,self.zip)
        self.key=Ed25519PrivateKey.generate();self.pub=base64.b64encode(self.key.public_key().public_bytes(serialization.Encoding.Raw,serialization.PublicFormat.Raw)).decode();self.assets=self.root/'assets';self.assets.mkdir();self.keyfile=self.assets/'update_public_key.json';self.keyfile.write_text(json.dumps({'ed25519':self.pub}));self.state=self.root/'state'
        self.payload={'schema':1,'platform':'macos-apple-silicon','cache_schema':1,'package_kind':'python-shell-app','version':'0.7.22','asset':{'url':'https://github.com/bruh180308/Shanatomy/releases/download/0.7.22/Shanatomy-MacOS.zip','sha256':digest(self.zip),'size':self.zip.stat().st_size}};self.sign()
    def sign(self):self.envelope={'payload':self.payload,'signature':base64.b64encode(self.key.sign(canonical(self.payload))).decode()}
    def fetch(self,url,limit,output=None,progress=lambda n:None):
        if output:shutil.copy2(self.zip,output);progress(self.zip.stat().st_size);return self.zip.stat().st_size
        self.assertTrue(url.endswith('/update-macos.json'));return json.dumps(self.envelope).encode()
    def updater(self,native=False):return Updater(self.state,self.assets,'0.7.10',self.app,self.fetch,native)
    def staged(self):u=self.updater();self.assertEqual(u.prepare(),'restart');return u
    def test_native_variant_signed_without_changing_legacy_bridge(self):
        self.payload['native_asset']={**self.payload['asset'],'url':self.payload['asset']['url'].replace('Shanatomy-MacOS.zip','Shanatomy-MacOS-Native.zip')}
        self.sign()
        self.assertEqual(verify_macos(self.envelope,self.pub,'bruh180308/Shanatomy',False)['package_kind'],'python-shell-app')
        native=verify_macos(self.envelope,self.pub,'bruh180308/Shanatomy',True)
        self.assertEqual(native['package_kind'],'self-contained-app');self.assertTrue(native['asset']['url'].endswith('/Shanatomy-MacOS-Native.zip'))
        self.assertEqual(self.payload['package_kind'],'python-shell-app','selection must not mutate signed payload')
        self.payload['native_asset']['sha256']='f'*64
        with self.assertRaises(Exception):verify_macos(self.envelope,self.pub,'bruh180308/Shanatomy',True)
        self.payload['native_asset']['url']='https://github.com/attacker/repo/releases/download/x/Shanatomy-MacOS-Native.zip';self.sign()
        with self.assertRaises(ValueError):verify_macos(self.envelope,self.pub,'bruh180308/Shanatomy',True)
    def test_external_manifest_preserves_final_signed_executable(self):
        (self.new/'Contents/Resources/MAC_PACKAGE_MANIFEST.json').unlink()
        binary=self.new/'Contents/MacOS/ShanatomyMac';binary.write_bytes(b'\xcf\xfa\xed\xfeFINAL-SIGNED-EXECUTABLE')
        before=digest(binary);outside=self.root/'MAC_PACKAGE_MANIFEST.json';manifest(self.new,outside)
        self.assertEqual(digest(binary),before);self.assertFalse((self.new/'Contents/Resources/MAC_PACKAGE_MANIFEST.json').exists())
        zip_app(self.new,self.zip,{'MAC_PACKAGE_MANIFEST.json':outside})
        app=extract_app(self.zip,self.root/'native.app')
        self.assertEqual(digest(app/'Contents/MacOS/ShanatomyMac'),before);self.assertEqual(bundle_hash(app),bundle_hash(self.new))
    def test_signed_download_resume(self):
        self.staged();self.assertIsNotNone(self.updater().pending);self.assertEqual(self.updater().prepare(),'restart');self.assertEqual(bundle_hash(self.app),bundle_hash(make_app(self.root/'same-old.app','0.7.10')))
    def test_tampering_wrong_platform_repo_cache_and_native(self):
        for name,value in [('platform','windows-x64'),('cache_schema',2),('package_kind','exe')]:
            old=self.payload.get(name);self.payload[name]=value;self.sign()
            with self.assertRaises(ValueError):self.updater().prepare()
            self.payload[name]=old
        self.payload['asset']['url']='https://github.com/wrong/repo/releases/download/x/Shanatomy-MacOS.zip';self.sign()
        with self.assertRaises(ValueError):self.updater().prepare()
    def test_invalid_signature(self):
        self.payload['version']='0.8.0'
        with self.assertRaises(Exception):self.updater().prepare()
    def test_current_version_no_download(self):
        self.payload['version']='0.7.10';self.sign();self.assertEqual(self.updater().prepare(),'continue')
    def test_native_refuses_source(self):
        with self.assertRaises(ValueError):self.updater(True).prepare()
    def test_cancel_before_download(self):self.assertEqual(self.updater().prepare(cancelled=lambda:True),'cancelled');self.assertFalse((self.state/'updates/pending.json').exists())
    def test_cancel_mid_download(self):
        cancelled={'v':False};u=self.updater();original=self.fetch
        def fetcher(url,limit,output=None,progress=lambda n:None):
            if output:cancelled['v']=True
            return original(url,limit,output,progress)
        u.fetcher=fetcher
        with self.assertRaises(InterruptedError):u.prepare(cancelled=lambda:cancelled['v'])
        self.assertFalse((self.state/'updates/pending.json').exists())
    def test_corrupt_zip_hash(self):
        self.payload['asset']['sha256']='0'*64;self.sign()
        with self.assertRaises(ValueError):self.updater().prepare()
        self.assertFalse((self.state/'updates/download.part').exists())
    def test_inner_version_kind_and_manifest_checked(self):
        self.payload['version']='0.8.0';self.sign()
        with self.assertRaises(ValueError):self.updater().prepare()
        self.payload['version']='0.7.22';self.payload['package_kind']='self-contained-app';self.sign()
        with self.assertRaises(ValueError):self.updater().prepare()
    def test_traversal_symlink_duplicate_and_size_rejected(self):
        for name,mode in [('../escape',stat.S_IFREG),('/escape',stat.S_IFREG),('a\\b',stat.S_IFREG),('link',stat.S_IFLNK)]:
            bad=self.root/'bad.zip'
            with zipfile.ZipFile(bad,'w') as z:
                info=zipfile.ZipInfo(name);info.external_attr=(mode|0o644)<<16;z.writestr(info,b'bad')
            with self.assertRaises(ValueError):extract_app(bad,self.root/'reject.app')
            self.assertFalse((self.root/'reject.app').exists())
    def test_unlisted_inner_file_rejected(self):
        (self.new/'Contents/Resources/extra').write_bytes(b'not in manifest');zip_app(self.new,self.zip)
        with self.assertRaises(ValueError):extract_app(self.zip,self.root/'reject.app')
    def test_apply_backup_restart_without_touching_ca(self):
        ca=self.root/'Complete Anatomy.app';ca.mkdir();sentinel=ca/'do-not-touch';sentinel.write_bytes(b'original');old=bundle_hash(self.app);self.staged();launch=Mock()
        apply_pending(self.state,self.keyfile,10,lambda pid:None,launch);launch.assert_called_once_with(self.app);self.assertEqual(bundle_hash(self.app),bundle_hash(self.new));self.assertEqual(bundle_hash(self.app.with_name('Shanatomy Mac.previous.app')),old);self.assertEqual(sentinel.read_bytes(),b'original')
    def test_changed_target_refused(self):
        self.staged();(self.app/'Contents/Resources/changed').write_bytes(b'new')
        with self.assertRaises(ValueError):apply_pending(self.state,self.keyfile,10,lambda pid:None,Mock())
    def test_replace_failure_rolls_back(self):
        self.staged();old=bundle_hash(self.app);real=os.replace
        def fail(a,b):
            if str(a).endswith('.incoming.app'):raise OSError('simulated lock')
            return real(a,b)
        with patch('mac_updater.os.replace',side_effect=fail):
            with self.assertRaises(OSError):apply_pending(self.state,self.keyfile,10,lambda pid:None,Mock())
        self.assertEqual(bundle_hash(self.app),old)
    def test_receipt_failure_still_restarts(self):
        self.staged();real=atomic_json;launch=Mock()
        def fail(path,value):
            if path.name=='last_update.json':raise OSError('locked')
            return real(path,value)
        with patch('mac_updater.atomic_json',side_effect=fail):apply_pending(self.state,self.keyfile,10,lambda pid:None,launch)
        launch.assert_called_once_with(self.app)
    def test_unknown_backup_not_deleted(self):
        self.staged();backup=make_app(self.root/'Shanatomy Mac.previous.app','0.7.1');before=bundle_hash(backup)
        with self.assertRaises(FileNotFoundError):apply_pending(self.state,self.keyfile,10,lambda pid:None,Mock())
        self.assertEqual(bundle_hash(backup),before)
    def test_wrong_bundle_never_replaced(self):
        with (self.app/'Contents/Info.plist').open('wb') as f:plistlib.dump({'CFBundleIdentifier':'com.CompleteAnatomy','CFBundleExecutable':'ShanatomyMac'},f)
        with self.assertRaises(ValueError):self.updater()
    def test_helper_source_detaches_own_files_only(self):
        u=self.staged()
        with patch('mac_updater.subprocess.Popen') as launch:u.schedule()
        self.assertIn('--apply',launch.call_args.args[0]);self.assertTrue((self.state/'updates/mac_updater.py').exists());self.assertEqual(bundle_hash(self.app),bundle_hash(make_app(self.root/'old-reference.app','0.7.10')))
    def test_modified_helper_not_overwritten(self):
        u=self.staged()
        with patch('mac_updater.subprocess.Popen'):u.schedule()
        helper=self.state/'updates/mac_updater.py';helper.write_bytes(b'unknown-content')
        with patch('mac_updater.subprocess.Popen') as launch:
            with self.assertRaises(ValueError):u.schedule()
        launch.assert_not_called();self.assertEqual(helper.read_bytes(),b'unknown-content')
    def test_known_helper_can_be_reused(self):
        u=self.staged()
        with patch('mac_updater.subprocess.Popen') as launch:u.schedule();u.schedule()
        self.assertEqual(launch.call_count,2)
    def test_duplicate_and_expansion_limit(self):
        import warnings
        bad=self.root/'bad.zip'
        with warnings.catch_warnings():
            warnings.simplefilter('ignore')
            with zipfile.ZipFile(bad,'w') as z:z.writestr('same',b'x');z.writestr('same',b'y')
        with self.assertRaises(ValueError):extract_app(bad,self.root/'reject.app')
        with zipfile.ZipFile(bad,'w') as z:z.writestr('one',b'12')
        with patch('mac_updater.MAX_EXPANDED',1):
            with self.assertRaises(ValueError):extract_app(bad,self.root/'reject.app')
