import unittest
import test_updater_mac as fixtures
from mac_updater import atomic_json,bundle_hash
class FailedPackageTests(unittest.TestCase):
 setUp=fixtures.UpdateMacTests.setUp
 sign=fixtures.UpdateMacTests.sign
 fetch=fixtures.UpdateMacTests.fetch
 updater=fixtures.UpdateMacTests.updater
 staged=fixtures.UpdateMacTests.staged
 def test_same_failed_package_never_restarts_update_loop(self):
  self.staged();original=bundle_hash(self.app);atomic_json(self.state/'updates/apply_error.json',{'attempted_sha256':self.payload['asset']['sha256']})
  value=self.updater();self.assertIsNone(value.pending)
  with self.assertRaises(ValueError):value.prepare()
  self.assertEqual(bundle_hash(self.app),original)
