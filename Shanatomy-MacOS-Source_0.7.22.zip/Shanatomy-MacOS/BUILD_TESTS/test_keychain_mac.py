import ctypes,unittest
from unittest.mock import Mock,patch
from mac_security import load_key,store_key
class KeychainTests(unittest.TestCase):
    def test_missing_and_denied(self):
        sec=Mock();cf=Mock();sec.SecKeychainFindGenericPassword.return_value=-25300
        with patch('mac_security.libraries',return_value=(sec,cf)):self.assertEqual(load_key(),'')
        sec.SecKeychainFindGenericPassword.return_value=-25293
        with patch('mac_security.libraries',return_value=(sec,cf)):
            with self.assertRaises(RuntimeError):load_key()
    def test_read_frees_data_and_item(self):
        sec=Mock();cf=Mock();buffer=ctypes.create_string_buffer(b'LOCAL-TEST-KEY')
        def find(*args):
            ctypes.cast(args[5],ctypes.POINTER(ctypes.c_uint32))[0]=14
            ctypes.cast(args[6],ctypes.POINTER(ctypes.c_void_p))[0]=ctypes.addressof(buffer)
            ctypes.cast(args[7],ctypes.POINTER(ctypes.c_void_p))[0]=123;return 0
        sec.SecKeychainFindGenericPassword.side_effect=find
        with patch('mac_security.libraries',return_value=(sec,cf)):self.assertEqual(load_key(),'LOCAL-TEST-KEY')
        sec.SecKeychainItemFreeContent.assert_called_once();cf.CFRelease.assert_called_once()
    def test_add_or_update_without_shell(self):
        sec=Mock();cf=Mock();sec.SecKeychainFindGenericPassword.return_value=-25300;sec.SecKeychainAddGenericPassword.return_value=0
        with patch('mac_security.libraries',return_value=(sec,cf)),patch('mac_security.subprocess.run') as shell:store_key('LOCAL-TEST-KEY');shell.assert_not_called()
        sec.SecKeychainAddGenericPassword.assert_called_once()
        def find(*args):ctypes.cast(args[7],ctypes.POINTER(ctypes.c_void_p))[0]=123;return 0
        sec.SecKeychainFindGenericPassword.side_effect=find;sec.SecKeychainItemModifyAttributesAndData.return_value=0
        with patch('mac_security.libraries',return_value=(sec,cf)):store_key('NEW-TEST-KEY')
        sec.SecKeychainItemModifyAttributesAndData.assert_called_once();cf.CFRelease.assert_called_once()
    def test_store_denied_does_not_write_plaintext(self):
        sec=Mock();sec.SecKeychainFindGenericPassword.return_value=-25293
        with patch('mac_security.libraries',return_value=(sec,Mock())):
            with self.assertRaises(RuntimeError):store_key('LOCAL-TEST-KEY')
        sec.SecKeychainAddGenericPassword.assert_not_called()
if __name__=='__main__':unittest.main()
