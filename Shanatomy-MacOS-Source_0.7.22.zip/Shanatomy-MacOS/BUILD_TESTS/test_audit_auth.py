import threading,unittest
from license_auth import Client,Rejected
class AuditAuthTests(unittest.TestCase):
 def test_refresh_keeps_published_license_valid_until_commit(self):
  entered=threading.Event();release=threading.Event()
  class Expiry:
   def __int__(self):entered.set();release.wait(2);return 3000
  calls=[0]
  def transport(f):
   if f['type']=='init':return {'success':True,'sessionid':'fake'}
   calls[0]+=1
   return {'success':True,'info':{'hwid':'fake','subscriptions':[{'expiry':2000 if calls[0]==1 else Expiry()}]}}
  client=Client(transport,lambda:'fake',lambda:1000);client.activate('TEST')
  worker=threading.Thread(target=lambda:client.activate('TEST'));worker.start()
  try:
   self.assertTrue(entered.wait(2));self.assertEqual(client.snapshot()['expires'],2000);self.assertTrue(client.snapshot()['valid'])
  finally:release.set();worker.join(3)
  self.assertEqual(client.snapshot()['expires'],3000)
 def test_malformed_signed_info_invalidates_prior_license(self):
  client=Client(lambda f:{'success':True,'sessionid':'fake','info':{'hwid':'fake','subscriptions':[{'expiry':2000}]}},lambda:'fake',lambda:1000);client.activate('TEST')
  client.transport=lambda f:{'success':True,'info':[]}
  with self.assertRaises(Rejected):client.activate('TEST')
  self.assertFalse(client.snapshot()['valid'])
