import os,tempfile,tkinter as tk,unittest
from unittest.mock import patch
from license_auth import activation_dialog,Client,UpdateUnavailable

@unittest.skipUnless(os.name=='nt','Windows native dialog')
class ExternalDialogTests(unittest.TestCase):
    def dialog(self,after_auth,continue_on_error=False):
        root=tk.Tk();root.withdraw();self.addCleanup(root.destroy);windows=[];callbacks={};original_top=tk.Toplevel;original_bind=tk.Canvas.tag_bind
        def top(*args,**kwargs):
            win=original_top(*args,**kwargs);win.withdraw();windows.append(win);return win
        def bind(canvas,tag,sequence,func=None,add=None):
            if tag=='check' and sequence=='<Button-1>':callbacks['submit']=func
            return original_bind(canvas,tag,sequence,func,add)
        def submit():
            self.assertTrue(windows[0].overrideredirect())
            entry=next(x for x in windows[0].winfo_children() if isinstance(x,tk.Entry));entry.insert(0,'LOCAL-TEST-KEY');callbacks['submit'](None)
        timeout={'value':False}
        def force_close():
            timeout['value']=True
            if windows[0].winfo_exists():windows[0].tk.call(windows[0].protocol('WM_DELETE_WINDOW'))
        def continue_when_ready():
            canvas=next(x for x in windows[0].winfo_children() if isinstance(x,tk.Canvas));texts=[canvas.itemcget(i,'text') for i in canvas.find_all() if canvas.type(i)=='text']
            if 'Mở ứng dụng' in texts:callbacks['submit'](None)
            else:root.after(20,continue_when_ready)
        transport=lambda fields:{'success':True,'sessionid':'test-session','info':{'hwid':'test-machine','subscriptions':[{'expiry':2000}]}}
        client=Client(transport,lambda:'test-machine',lambda:1000)
        with tempfile.TemporaryDirectory() as state,patch('license_auth.saved_key',return_value=''),patch('license_auth.save_key'),patch('tkinter.Toplevel',side_effect=top),patch('tkinter.Canvas.tag_bind',new=bind):
            root.after(100,submit);root.after(5000,force_close)
            if continue_on_error:root.after(200,continue_when_ready)
            result=activation_dialog(root,state,client,after_auth)
            self.assertFalse(timeout['value']);self.assertIs(result,client)
        return client
    def test_update_progress_and_restart_result(self):
        def preflight(client,notify,cancelled):
            notify({'state':'checking','message':'Đang kiểm tra bản mới…'});notify({'state':'downloading','message':'Đang tải bản mới…','progress':50});notify({'state':'staged','message':'Đã xác minh.','progress':100});return 'restart'
        self.assertTrue(self.dialog(preflight).restart_requested)
    def test_update_failure_offers_current_version(self):
        def preflight(*args):raise UpdateUnavailable('offline')
        self.dialog(preflight,True)
    def test_error_after_verified_download_requires_restart(self):
        from types import SimpleNamespace
        def preflight(client,*args):
            client.updater=SimpleNamespace(pending={'verified':True})
            raise UpdateUnavailable('observer failed after staging')
        self.assertTrue(self.dialog(preflight).restart_requested)

if __name__=='__main__':unittest.main()
