import unittest
from unittest.mock import Mock
from mac_lifecycle import SessionCleaner
class AuditCleanerTests(unittest.TestCase):
 def test_process_query_failure_never_restores_running_session(self):
  item=Mock();item.removed=False;clock=[0];reads=iter([True,False,False,False,OSError('query')])
  def running():
   value=next(reads)
   if isinstance(value,Exception):raise value
   return value
  cleaner=SessionCleaner(item,running,lambda:clock[0])
  for _ in range(4):cleaner.tick()
  item.uninstall.assert_not_called();self.assertFalse(cleaner.done);self.assertEqual(cleaner.absent,0)
