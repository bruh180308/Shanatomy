import unittest
from license_auth import Client,Rejected,NetworkError
class AuthRecoveryTests(unittest.TestCase):
 def test_expired_session_renews_and_rechecks_hwid(self):
  calls=[]
  def transport(f):
   calls.append(f['type'])
   if f['type']=='init':return {'success':True,'sessionid':'new-session'}
   if f.get('sessionid')=='expired':return {'success':False,'message':'Session ID is invalid'}
   return {'success':True,'info':{'hwid':'a','subscriptions':[{'expiry':'2000'}]}}
  c=Client(transport,lambda:'a',lambda:1000);c.session='expired';c.activate('FAKE-KEY')
  self.assertTrue(c.snapshot()['valid']);self.assertEqual(calls,['license','init','license'])
 def test_revoked_license_after_valid_session_is_invalid(self):
  c=Client(lambda f:{'success':False,'message':'banned'},lambda:'a',lambda:1000);c.session='s';c.valid=True;c.expires=2000
  with self.assertRaises(Rejected):c.activate('FAKE-KEY')
  self.assertFalse(c.snapshot()['valid'])
 def test_refresh_renews_expired_session_without_bypassing_license(self):
  calls=[]
  def transport(f):
   calls.append(f['type'])
   if f['type']=='check':return {'success':False,'message':'session expired'}
   if f['type']=='init':return {'success':True,'sessionid':'fresh'}
   return {'success':True,'info':{'hwid':'a','subscriptions':[{'expiry':2000}]}}
  c=Client(transport,lambda:'a',lambda:1000);c.valid=True;c.expires=2000;c.session='old';c.key='FAKE-KEY';c.refresh()
  self.assertEqual(calls,['check','init','license']);self.assertTrue(c.snapshot()['valid'])
