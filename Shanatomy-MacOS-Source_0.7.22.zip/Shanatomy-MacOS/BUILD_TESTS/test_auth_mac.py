import json,time,unittest,tempfile
from unittest.mock import MagicMock,patch
from pathlib import Path
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization
from license_auth import *

class LicenseTests(unittest.TestCase):
    def setUp(self):
        self.now=1000;self.requests=[]
        def transport(fields):
            self.requests.append(fields)
            if fields['type']=='init':return {'success':True,'sessionid':'session'}
            if fields['type']=='check':return {'success':True}
            return {'success':True,'info':{'hwid':'machine-a','subscriptions':[{'expiry':'2000'}]}}
        self.transport=transport;self.client=Client(transport,lambda:'machine-a',lambda:self.now)
    def test_activation_and_one_init(self):
        self.client.activate('TEST-KEY');self.client.refresh();self.assertTrue(self.client.snapshot()['valid']);self.assertEqual(sum(r['type']=='init' for r in self.requests),1);self.assertEqual(self.requests[1]['hwid'],'machine-a');self.assertEqual(self.requests[0]['ver'],'1.0')
    def test_hwid_mismatch(self):
        self.client.hwid_fn=lambda:'machine-b'
        with self.assertRaises(Rejected):self.client.activate('TEST-KEY')
        self.assertFalse(self.client.valid)
    def test_expired(self):
        self.now=2100
        with self.assertRaises(Rejected):self.client.activate('TEST-KEY')
    def test_no_subscription(self):
        self.client.transport=lambda f:{'success':True,'sessionid':'s','info':{'hwid':'machine-a'}}
        with self.assertRaises(Rejected):self.client.activate('TEST-KEY')
    def test_invalid_key(self):
        self.client.transport=lambda f:{'success':False,'message':'Invalid license key'}
        with self.assertRaises(Rejected):self.client.activate('TEST-KEY')
    def test_revoked_session(self):
        self.client.activate('TEST-KEY');self.client.transport=lambda f:{'success':False,'message':'banned'}
        with self.assertRaises(Rejected):self.client.refresh()
        self.assertFalse(self.client.valid)
    def test_network_grace(self):
        self.client.activate('TEST-KEY');self.client.transport=lambda f:(_ for _ in ()).throw(NetworkError('offline'));self.now=1100;self.client.refresh();self.assertTrue(self.client.valid);self.now=1950
        with self.assertRaises(NetworkError):self.client.refresh()
        self.assertFalse(self.client.valid)
    def test_key_recheck_network_failure_keeps_grace(self):
        self.client.activate('TEST-KEY');self.now=1100
        self.client.transport=lambda f:{'success':True} if f['type']=='check' else (_ for _ in ()).throw(NetworkError('offline'))
        self.client.refresh();self.assertTrue(self.client.valid)
    def test_signature_and_tamper(self):
        key=Ed25519PrivateKey.generate();pub=key.public_key().public_bytes(serialization.Encoding.Raw,serialization.PublicFormat.Raw).hex();body=json.dumps({'success':True}).encode();stamp='1000';headers={'x-signature-timestamp':stamp,'x-signature-ed25519':key.sign(stamp.encode()+body).hex()}
        self.assertTrue(verified_response(body,headers,lambda:1000,pub)['success'])
        for changed in (b'{"success":false}',body+b' '):
            with self.assertRaises(AuthError):verified_response(changed,headers,lambda:1000,pub)
        with self.assertRaises(AuthError):verified_response(body,headers,lambda:2000,pub)
        with self.assertRaises(AuthError):verified_response(body,{},lambda:1000,pub)

if __name__=="__main__":unittest.main()
