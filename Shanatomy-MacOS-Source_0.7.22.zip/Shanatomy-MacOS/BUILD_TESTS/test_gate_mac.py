import tempfile,unittest
from pathlib import Path
from unittest.mock import Mock,patch
import cavi_mac
class MacGateTests(unittest.TestCase):
    def run_gate(self,auth):
        with tempfile.TemporaryDirectory() as temp:
            home=Path(temp);info={'path':str(home/'Complete Anatomy.app'),'bundle_id':'com.CompleteAnatomy','version':'12.5.1'};root=Mock();item=Mock()
            with patch.object(cavi_mac.sys,'platform','darwin'),patch.dict('sys.modules',{'fcntl':Mock(LOCK_EX=2,LOCK_NB=4,LOCK_UN=8)}),patch.object(cavi_mac.Path,'home',return_value=home),patch.object(cavi_mac,'app_info',return_value=info),patch.object(cavi_mac,'discover_caches',return_value=[]),patch.object(cavi_mac,'dialog'),patch.object(cavi_mac,'write_diagnostic',return_value=home/'diagnostic.json'),patch('tkinter.Tk',return_value=root),patch('license_auth.activation_dialog',return_value=auth),patch.object(cavi_mac,'Installation',return_value=item),patch.object(cavi_mac.subprocess,'run') as app:
                cavi_mac.main(['--gui','--app',str(home/'Complete Anatomy.app')]);app.assert_not_called();item.prepare.assert_not_called();item.apply.assert_not_called()
        return auth
    def test_cancel_no_cache_no_launch(self):self.run_gate(None)
    def test_verified_update_restarts_before_cache(self):
        auth=Mock(restart_requested=True);auth.snapshot.return_value={'valid':True};self.run_gate(auth);auth.updater.schedule.assert_called_once()
    def test_staged_even_without_restart_flag_blocks_app(self):
        auth=Mock(restart_requested=False);auth.snapshot.return_value={'valid':True};auth.updater.pending={'verified':True};self.run_gate(auth);auth.updater.schedule.assert_called_once()
    def test_expiry_after_preflight_blocks_app(self):
        auth=Mock(restart_requested=False);auth.snapshot.return_value={'valid':False};self.run_gate(auth);auth.updater.schedule.assert_not_called()
if __name__=='__main__':unittest.main()
