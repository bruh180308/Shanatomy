# Shanatomy Mac 0.7.22 — Apple Silicon

Bản mới dùng toàn bộ menu Windows0.7.22: một nút chuyển VI/English, bind phím đơn/tổ hợp/Cmd/Option/nút chuột, hiệu ứng menu/checkbox/đóng, icon glow/fade/kéo/bám bốn rìa thành tab, bốn màu và màu riêng, đổi icon riêng cạnh bảng màu, link Zalo tác giả, thời hạn key, bổ sung mô tả chưa hoàn thành. Dữ liệu dịch vẫn0.6.29; không tự tăng tiến độ y khoa. Bản Mac0.7.0 cũ đã được người dùng xác nhận chạy; **bản0.7.22 cần thử lại trên Mac thật**.

## Chạy lần đầu

1. Chuyển `Shanatomy-MacOS.zip` sang Mac, giải nén bằng Finder. Giữ cả thư mục `Shanatomy-MacOS`, mở `Shanatomy Mac.app` hoặc `BAT_VIET_HOA_MAC.command`. Không mở app Việt hóa cũ cùng lúc; nếu Terminal cũ còn chạy, dừng riêng bằng Ctrl+C. Công cụ không tự đóng Complete Anatomy.
2. Gói được tạo trên Windows này là `.app` launcher Python kiểu hôm trước, **không phải Mach-O tự chứa**. Cần Python3.10+ có Tk (bản universal2 từ python.org). Nó chuẩn bị `cryptography==50.0.1` trong venv riêng tại `~/Library/Application Support/HungLe/CompleteAnatomyVietnameseMac/runtime-<version>` nếu Python hiện tại chưa có; lần đầu cần mạng. Không cài Xcode, không sửa thư viện Python hệ thống. Nếu lỗi, xem `runtime_setup.log`. Python Homebrew không có Tk sẽ không được chọn; dùng Python.org có Tk.
3. Menu key bo góc, không titlebar, có × riêng và kéo phần đầu; Escape hoặc Cmd+W/Cmd+Q đóng cửa sổ. Nhập key → Kiểm tra → xác thực KeyAuth → kiểm tra/tải online → bản đã xác minh thì restart **Shanatomy** trước khi mở/Việt hóa Complete Anatomy. Nếu GitHub chưa có manifest Mac hoặc mạng lỗi thì hiện **Mở ứng dụng** để dùng bản hiện tại sau key hợp lệ. Hủy cửa sổ không mở app.
4. App KeyAuth vẫn `Shanatomy`, Owner `EV6jVLnFyQ`, auth version **1.0**. Bật HWID Lock và Force HWID trên dashboard. Mac dùng SHA-256 của IOPlatformUUID với namespace riêng; key đã gắn Windows sẽ bị từ chối trên Mac, cần key khác hoặc reset chuyển máy. Key lưu **macOS Keychain** riêng của Shanatomy, không plain text/argv. macOS có thể hỏi cho phép truy cập Keychain. Cần đồng hồ đúng; kiểm signature/timestamp server. Không chứa app/seller/admin secret.
5. Nhớ lựa chọn Complete Anatomy gốc từ bộ hôm trước; không tìm được thì Finder cho chọn `.app` gốc, bao gồm app iOS Wrapped trên Apple Silicon. Có thể chọn cache `Mobile3D4MEngine` trong Library; không chọn bên trong Complete Anatomy.app. Nếu app chưa tạo cache, mở app gốc một lần rồi tự thoát và chạy Shanatomy.
6. Nếu phiên Complete Anatomy cũ đã nạp menu cũ, tự đóng/mở lại một lần để nạp menu mới. Icon ở cạnh có thể thành tab vạch nắm; kéo ra để thấy ảnh. Menu đổi ảnh PNG/JPG/WebP giữ trên máy, không gửi lên mạng. Các bind chỉ trong WebView, không global macOS.

Nếu Gatekeeper chặn app chưa notarize, xem [Apple: mở app chưa xác minh](https://support.apple.com/102445) và chỉ xét riêng Shanatomy; không tắt Gatekeeper toàn máy. Nếu `.command` mất quyền chạy sau chuyển tệp, gõ `bash ` rồi kéo command vào Terminal. ZIP có UNIX executable permissions chuẩn.

## Cache, nâng cấp và gỡ

State `~/Library/Application Support/HungLe/CompleteAnatomyVietnameseMac`. Cơ chế chỉ sửa **index.html của cache Mac** và một script `ca-vi-macos-owned-<hash>.js`, không chép bundle/index Windows vào Mac, không Frida/native injection, không thay DLL/native app/loadscreen, không phá chữ ký Complete Anatomy. Sao lưu nguyên index Mac, script/hash/token/port vào registry sở hữu. Main.bundle Mac luôn giữ nguyên và được theo dõi hash; thay phiên bản thì dừng nạp để đối chiếu.

Registry0.7.0 đã nhận diện được khôi phục/xóa script cũ trước khi tạo bản0.7.22; index/script/backup lạ không ghi đè. Bản nguồn mới tái dựng từ index Mac gốc, không chồng các bản vá. Khi app thực sự **Quit** (Cmd+Q hoặc Quit menu), NSWorkspace xác nhận vắng app3 mẫu liên tiếp rồi kiểm lại, khôi phục index đúng hash/xóa script sở hữu và launcher tự thoát. Đóng riêng cửa sổ Mac nhưng app vẫn còn trong Dock có thể chưa là Quit; giữ launcher để tiếp tục phiên. Không đọc được trạng thái thì không coi là app đã thoát. Mở lại trong lúc kiểm thì hoãn dọn.

Gỡ trong menu hoặc `GO_VIET_HOA_MAC.command` hoạt động kể cả không có key/mạng. Giữ tài khoản, bài học, mô hình và main.bundle; gỡ preference caVi trong phiên. Chỉ cam kết gỡ bản Mac được nhận diện; không xóa mọi công cụ khác/phiên bản tương lai chưa biết. Dữ liệu nguồn, runtime/keychain và bộ cài ngoài app không bị coi là phần đã tiêm vào Complete Anatomy. Lỗi phục hồi giữ backup và cleanup_error; không xóa mù. Ctrl+C/dừng launcher cũng cố phục hồi tệp trên đĩa; menu trong phiên đã nạp có thể cần app tự mở lại.

Key hết hạn/thu hồi: ngừng watch, phục hồi English, controller báo license invalid để menu dispose qua heartbeat30s, chờ rồi tự thoát; app vẫn mở. Kiểm lại mỗi300s, grace mạng900s nhưng không vượt expiry; khởi động cần online.

## Cập nhật online chung GitHub

Repo `https://github.com/bruh180308/Shanatomy`. Trong **cùng GitHub Release tag0.7.22**, đăng bốn Assets:

- `Shanatomy-Windows.exe` + `update.json` (Windows đã ký trước, giữ nguyên).
- `Shanatomy-MacOS.zip` + `update-macos.json` (Mac ký riêng).

Mac chỉ lấy `https://github.com/bruh180308/Shanatomy/releases/latest/download/update-macos.json`; Windows cũ chỉ đọc `update.json`, nên không tải nhầm nền tảng. Đăng đủ hai manifest trên mỗi Release mới; nếu đăng tag mới chỉ có Mac, Windows không tìm được metadata và sẽ báo lỗi cập nhật. Không đổi ZIP sau khi ký; không dùng manifest ZIP nguồn cho ZIP tự chứa. Chữ ký Ed25519 dùng chung public key pinned; kiểm nền tảng, version, repo URL, SHA-256/kích thước, cache_schema1, package_kind. Mac metadata không giả định Appxversion Windows12.5.1.0; cache Mac kiểm riêng trên máy bằng cấu trúc/backup/main hash.

Sau key: tải `.part`, kiểm hash/signature, giải thử kiểm path/traversal/symlink/duplicate/giới hạn/manifest nội bộ và app ID/version trước staging. Helper riêng chờ launcher cũ thoát, kiểm bundle cũ chưa đổi, thay **Shanatomy Mac.app** (không Complete Anatomy), giữ một `.previous.app`, rollback nếu lỗi. Khởi động lại app mới rồi xác thực/check lại trước Việt hóa. Bundle cũ đổi hoặc backup không khớp thì từ chối thay/xóa. Bản xác minh staged chặn mở Complete Anatomy bằng launcher cũ. Helper không kill process. Lỗi cập nhật trước staging cho dùng bản hiện tại; lỗi thay có recovery một lần và giữ dữ liệu để tra cứu.

State `updates`: ready.zip, pending.json, helper, last_update.json/apply_error.json; không sửa/xóa thủ công khi chưa đối chiếu. Bundle/source ZIP và bản tự chứa là hai kiểu khác nhau: source nhận được native hoặc source; **native chỉ tự cập nhật sang native**, không tự biến thành bản cần Python.

## Bản tự chứa cho bạn bè — dựng trên Mac

Mở `TAO_APP_TU_CHUA_TREN_MAC.command`: dựng Python/PyInstaller trong venv riêng, tải cryptography/PyInstaller, xuất `BAN_TU_CHUA/Shanatomy Mac.app` và `BAN_TU_CHUA/Shanatomy-MacOS.zip`. Dùng onefile để ZIP không có symlink frameworks; đóng gói lại, đặt bundleID/version và ad-hoc codesign **chỉ Shanatomy của chính dự án**. Chưa Developer ID/notarization; không phải ký app gốc. Script yêu cầu Python arm64 trên Apple Silicon và dựng với target-arch arm64; nếu Python chạy qua Rosetta thì dừng để chọn Python arm64.

Để phát hành **bản tự chứa**: gửi ZIP dựng trên Mac về máy Windows giữ private signing key; chạy `sign_macos.py --zip <ZIP native> --kind self-contained-app --version 0.7.22 --key <private> --out <Release-folder> --tag 0.7.22`. Script kiểm nội dung trước ký. Hai asset Mac mới thay hai asset nguồn, EXE/update.json Windows giữ nguyên. Không đưa khóa ký riêng lên GitHub hoặc chép vào Mac cho bạn bè. Nếu dùng tag mới, chuẩn bị cả Windows manifest cho tag đó. Private key nằm riêng trong workspace chủ dự án, không trong ZIP.

[PyInstaller](https://pyinstaller.org/en/stable/usage.html) cần dựng riêng trên macOS; Windows không xuất được Mach-O native thực. Gói nguồn hiện tại để chủ dự án thử giống hôm trước, còn gói native phải dựng trên Mac trước phát hành cho người không có Python. Chưa thực hiện bước dựng native trên máy này.

## Kiểm tra, chẩn đoán và tiếp tục

`CHAN_DOAN_MAC.command`: đọc cache/app metadata/hash/frontend status, không sửa app hoặc bắt nhập key. File `CHAN_DOAN_MAC.json` tại state, Finder hiện để gửi lại. Không ghi key/session/token/HWID gốc; đường dẫn có thể chứa tên tài khoản. Nếu chưa thấy menu, gửi file này; không cần cấp Full Disk Access toàn máy hoặc sửa quyền Library mù.

Kiểm thử trên Windows: cache Mac giả lập, guard/upgrade/restore, API controller, session lifecycle bằng state giả, chữ ký/download/resume/ZIP/app replace/rollback/native-versus-source, auth protocol bằng response giả, DOM menu Windows được port sang Cmd/Option và dữ liệu0.6.29. QA số lượng thực tế trong báo cáo. **Chưa chạy IOPlatformUUID/Keychain/Tk Aqua/NSWorkspace thật, chưa thử upgrade/rollback trên APFS, chưa test CORS và picker ảnh trên WebView Mac mới**; không coi test giả lập là xác nhận thực tế. Hướng dẫn `README_VIET_HOA_CHAT_MOI.md` ở app folder Windows và nguồn `mac_0_7_22`/manifest trong bộ lưu dùng cho chat sau.
