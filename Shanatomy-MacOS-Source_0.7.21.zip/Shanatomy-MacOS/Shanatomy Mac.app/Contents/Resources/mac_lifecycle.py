"""Read NSWorkspace; never inject or send quit to Complete Anatomy."""
import ctypes,time

def app_running(bundle_id):
    try:
        ctypes.CDLL('/System/Library/Frameworks/AppKit.framework/AppKit')
        objc=ctypes.CDLL('/usr/lib/libobjc.A.dylib');objc.objc_getClass.argtypes=[ctypes.c_char_p];objc.objc_getClass.restype=ctypes.c_void_p;objc.sel_registerName.argtypes=[ctypes.c_char_p];objc.sel_registerName.restype=ctypes.c_void_p
        def call(obj,selector,result=ctypes.c_void_p,arg=None):
            types=[ctypes.c_void_p,ctypes.c_void_p]+([] if arg is None else [ctypes.c_ulong])
            fn=ctypes.CFUNCTYPE(result,*types)(('objc_msgSend',objc));args=[obj,objc.sel_registerName(selector.encode())]+([] if arg is None else [arg]);return fn(*args)
        pool=call(objc.objc_getClass(b'NSAutoreleasePool'),'new')
        try:
            workspace=call(objc.objc_getClass(b'NSWorkspace'),'sharedWorkspace');apps=call(workspace,'runningApplications')
            if not workspace or not apps:raise RuntimeError('Cannot read running applications')
            count=call(apps,'count',ctypes.c_ulong)
            if count>10000:raise RuntimeError('Invalid application count')
            for i in range(count):
                app=call(apps,'objectAtIndex:',arg=i)
                if call(app,'isTerminated',ctypes.c_bool):continue
                name=call(app,'bundleIdentifier')
                if name and call(name,'UTF8String',ctypes.c_char_p).decode()==bundle_id:return True
            return False
        finally:call(pool,'release',None)
    except Exception:return None

class SessionCleaner:
    def __init__(self,item,running,now=time.monotonic):self.item=item;self.running=running;self.now=now;self.started=now();self.seen=False;self.absent=0;self.done=False;self.error=''
    def tick(self):
        if self.done or self.item.removed:return
        try:state=self.running()
        except (OSError,RuntimeError):state=None
        if state is True:self.seen=True;self.absent=0;return
        if state is None:self.absent=0;return
        if not self.seen and self.now()-self.started<60:return
        self.absent+=1
        if self.absent<3:return
        try:confirmed=self.running()
        except (OSError,RuntimeError):confirmed=None
        if confirmed is not False:self.absent=0;return
        try:self.item.uninstall(reason='app_exit');self.done=True
        except Exception as e:self.error=str(e)
