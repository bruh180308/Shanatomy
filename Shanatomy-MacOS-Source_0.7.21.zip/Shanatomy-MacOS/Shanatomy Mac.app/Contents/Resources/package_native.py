"""Run on Mac after onefile build; zip the owned app, not Complete Anatomy."""
import argparse,hashlib,json,os,plistlib,stat,subprocess,zipfile
from pathlib import Path
APP_NAME='Shanatomy Mac.app';ROOT='Shanatomy-MacOS'
EXCLUDED={'Contents/Resources/MAC_PACKAGE_MANIFEST.json','Contents/_CodeSignature/CodeResources'}
def manifest(app,external=None):
    values={}
    for p in sorted(app.rglob('*')):
        if p.is_symlink():raise RuntimeError('Gói onefile không được chứa symlink.')
        if p.is_file() and p.relative_to(app).as_posix() not in EXCLUDED:
            values[p.relative_to(app).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
    path=Path(external) if external else app/'Contents/Resources/MAC_PACKAGE_MANIFEST.json';path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(values,indent=2),encoding='utf8')
def zip_app(app,output,extras=None):
    with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(app.rglob('*')):
            if not p.is_file():continue
            rel=p.relative_to(app).as_posix();i=zipfile.ZipInfo(ROOT+'/'+APP_NAME+'/'+rel);i.create_system=3;i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=((stat.S_IFREG|(0o755 if rel.startswith('Contents/MacOS/') else 0o644))<<16);z.writestr(i,p.read_bytes())
        for name,p in (extras or {}).items():
            i=zipfile.ZipInfo(ROOT+'/'+name);i.create_system=3;i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=((stat.S_IFREG|(0o755 if name.endswith('.command') else 0o644))<<16);z.writestr(i,Path(p).read_bytes())
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--app',required=True);p.add_argument('--out',required=True);p.add_argument('--version',default='0.7.21');a=p.parse_args();app=Path(a.app).resolve()
    if app.name!=APP_NAME:raise ValueError('Chỉ đóng gói Shanatomy Mac.app.')
    info=app/'Contents/Info.plist'
    with info.open('rb') as f:d=plistlib.load(f)
    if d.get('CFBundleIdentifier')!='vn.hungle.shanatomy.mac':raise ValueError('Sai bundle identifier.')
    d.update(CFBundleShortVersionString=a.version,CFBundleVersion=a.version,LSUIElement=True)
    with info.open('wb') as f:plistlib.dump(d,f)
    # Re-seal only Shanatomy's own app after adding the package manifest.
    if os.sys.platform=='darwin':subprocess.run(['/usr/bin/codesign','--force','--deep','--sign','-',str(app)],check=True)
    # Hash AFTER signing. Keep this manifest outside the signed app to avoid
    # a circular dependency between executable signature and resource manifest.
    output=Path(a.out);output.parent.mkdir(parents=True,exist_ok=True)
    external=output.parent/'MAC_PACKAGE_MANIFEST.json';manifest(app,external)
    zip_app(app,output,{'MAC_PACKAGE_MANIFEST.json':external});print('Đã đóng gói app Mac tự chứa; gửi ZIP về máy giữ khóa ký để ký update-macos.json.')
