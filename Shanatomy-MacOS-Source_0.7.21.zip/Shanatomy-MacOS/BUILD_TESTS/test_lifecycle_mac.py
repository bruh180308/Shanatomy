import plistlib,tempfile,unittest
from pathlib import Path
from unittest.mock import Mock,patch
from mac_lifecycle import SessionCleaner
from mac_security import machine_id
from cavi_mac import VERSION,save
import test_mac as cache_tests

class LifecycleMacTests(unittest.TestCase):
    def setUp(self):self.now=0;self.item=Mock(removed=False);self.running=Mock(return_value=True);self.cleaner=SessionCleaner(self.item,self.running,lambda:self.now)
    def test_quit_three_absent_samples(self):
        self.cleaner.tick();self.running.return_value=False
        self.cleaner.tick();self.cleaner.tick();self.item.uninstall.assert_not_called();self.cleaner.tick();self.item.uninstall.assert_called_once_with(reason='app_exit');self.assertTrue(self.cleaner.done)
    def test_unknown_not_closed(self):
        self.cleaner.tick();self.running.return_value=None
        for _ in range(10):self.cleaner.tick()
        self.item.uninstall.assert_not_called()
    def test_reopen_during_last_guard_defers(self):
        self.cleaner.tick();self.running.return_value=False;self.cleaner.tick();self.cleaner.tick();self.running.side_effect=[False,True];self.cleaner.tick();self.item.uninstall.assert_not_called()
    def test_never_started_waits_then_cleans(self):
        self.running.return_value=False
        for _ in range(3):self.cleaner.tick()
        self.item.uninstall.assert_not_called();self.now=61
        for _ in range(3):self.cleaner.tick()
        self.assertTrue(self.cleaner.done)
    def test_restore_failure_retries_keeps_backup(self):
        self.cleaner.tick();self.running.return_value=False;self.item.uninstall.side_effect=[OSError('locked'),None]
        for _ in range(3):self.cleaner.tick()
        self.assertFalse(self.cleaner.done);self.assertIn('locked',self.cleaner.error);self.cleaner.tick();self.assertTrue(self.cleaner.done)
    def test_mac_hardware_id_no_windows_dependency(self):
        body=plistlib.dumps([{'IOPlatformUUID':'12345678-1234-1234-1234-123456789ABC'}]);result=Mock(stdout=body)
        with patch('mac_security.subprocess.run',return_value=result):
            a=machine_id();self.assertEqual(len(a),64);self.assertEqual(a,machine_id())
        with patch('mac_security.subprocess.run',return_value=Mock(stdout=plistlib.dumps([{}]))):
            with self.assertRaises(RuntimeError):machine_id()

class UpgradeMacTests(unittest.TestCase):
    setUp=cache_tests.MacTests.setUp
    tearDown=cache_tests.MacTests.tearDown
    def test_legacy_registry_upgrades_removes_old_script(self):
        old=self.item.prepare(18768);self.item.apply();old['version']='0.7.0-mac-test2';save(self.item.registry_path,old)
        # Change template to model the actual old/new bootstrap difference.
        template=b'new-token="__CAVI_MAC_TOKEN__";port=__CAVI_MAC_PORT__;';import hashlib
        (self.assets/'bootstrap.template.js').write_bytes(template);self.item.report['bootstrap_template_sha256']=hashlib.sha256(template).hexdigest()
        new=self.item.prepare(18768);self.assertEqual(new['version'],VERSION);self.assertFalse((self.root/old['script_name']).exists());self.item.apply();self.item.uninstall();self.assertEqual(self.item.index.read_bytes(),self.original)
    def test_changed_mac_main_blocks_apply_but_is_never_overwritten(self):
        self.item.prepare(18768);main=self.root/'Resources/dist/main.bundle.js';main.write_bytes(b'updated-Mac-original')
        with self.assertRaises(RuntimeError):self.item.apply()
        self.assertEqual(main.read_bytes(),b'updated-Mac-original')
    def test_future_version_downgrade_refused(self):
        old=self.item.prepare(18768);old['version']='0.9.0';save(self.item.registry_path,old)
        with self.assertRaises(RuntimeError):self.item.prepare(18768)
    def test_persisted_future_version_without_registry_refused(self):
        save(self.item.state/'highest_version.json',{'version':'0.9.0'})
        with self.assertRaises(RuntimeError):self.item.prepare(18768)

if __name__=='__main__':unittest.main()
