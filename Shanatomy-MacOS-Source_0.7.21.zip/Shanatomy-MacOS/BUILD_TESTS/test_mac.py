import hashlib,json,plistlib,tempfile,unittest,urllib.request,urllib.error,socket
from pathlib import Path
from cavi_mac import Installation,Control,sha,save,app_info,discover_apps,discover_caches,validate_cache

class MacTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.home=Path(self.temp.name)
        self.root=self.home/'Library/Containers/com.test.CompleteAnatomy/Data/Documents/Mobile3D4MEngine'
        self.root.mkdir(parents=True);(self.root/'Resources/dist').mkdir(parents=True)
        self.original=b'<!doctype html><html><head><script>window.bridge={};window.injectScript=function(){};</script></head><body>Mac original</body></html>'
        (self.root/'index.html').write_bytes(self.original);(self.root/'Resources/dist/main.bundle.js').write_bytes(b'Mac-specific original JS; never replace with Windows JS')
        self.main_sha=sha(self.root/'Resources/dist/main.bundle.js')
        self.assets=self.home/'assets';self.assets.mkdir();template=b'const token="__CAVI_MAC_TOKEN__";const port=__CAVI_MAC_PORT__;'
        (self.assets/'bootstrap.template.js').write_bytes(template);save(self.assets/'MAC_ASSETS.json',{'bootstrap_template_sha256':hashlib.sha256(template).hexdigest()})
        self.state=self.home/'state';self.item=Installation(self.root,self.state,self.assets)
    def tearDown(self):self.temp.cleanup()
    def test_verified_expiry_embedded_without_key_or_hwid(self):
        self.item.license_snapshot={'valid':True,'expires':2000000000}
        self.item.prepare(18768)
        body=(self.state/'bootstrap.js').read_text()
        self.assertTrue(body.startswith('window.__caViVerifiedLicense='))
        self.assertIn('"expires":2000000000',body)
        self.assertNotIn('hwid',body)
    def test_changed_expiry_same_version_rebuilds_owned_script(self):
        self.item.license_snapshot={'valid':True,'expires':2000000000,'key':'NEVER-COPY'}
        first=self.item.prepare(18768);self.item.apply()
        self.item.license_snapshot={'valid':True,'expires':2000100000}
        second=self.item.prepare(18768);self.item.apply()
        self.assertNotEqual(first['script_sha256'],second['script_sha256'])
        self.assertIn('"expires":2000100000',(self.state/'bootstrap.js').read_text())
        self.assertNotIn('NEVER-COPY',(self.state/'bootstrap.js').read_text())
        self.item.uninstall();self.assertEqual(self.item.index.read_bytes(),self.original)
    def test_mac_original_roundtrip_preserves_main_and_lessons(self):
        user=self.root/'user_lesson.json';user.write_text('{"progress":19}')
        d=self.item.prepare(18768);self.item.apply()
        self.assertIn(b'ca-vi-macos-owned-bootstrap',(self.root/'index.html').read_bytes());self.assertTrue((self.root/d['script_name']).exists())
        self.assertEqual(sha(self.root/'Resources/dist/main.bundle.js'),self.main_sha)
        self.item.uninstall();self.assertEqual((self.root/'index.html').read_bytes(),self.original);self.assertFalse((self.root/d['script_name']).exists());self.assertEqual(user.read_text(),'{"progress":19}')
        self.assertEqual(sha(self.root/'Resources/dist/main.bundle.js'),self.main_sha);self.assertFalse((self.state/'registry.json').exists())
    def test_unknown_index_kept_and_backup_retained(self):
        self.item.prepare(18768);self.item.apply();self.item.index.write_bytes(b'new version')
        with self.assertRaises(RuntimeError):self.item.apply()
        with self.assertRaises(RuntimeError):self.item.uninstall()
        self.assertEqual(self.item.index.read_bytes(),b'new version');self.assertTrue((self.state/'original.index.html').exists())
    def test_unknown_bootstrap_kept(self):
        d=self.item.prepare(18768);self.item.apply();script=self.root/d['script_name'];script.write_bytes(b'not owned anymore')
        with self.assertRaises(RuntimeError):self.item.uninstall()
        self.assertEqual(script.read_bytes(),b'not owned anymore')
    def test_recopy_original_and_missing_owned_script_repaired(self):
        d=self.item.prepare(18768);self.item.apply();self.item.index.write_bytes(self.original);(self.root/d['script_name']).unlink()
        self.item.apply();self.assertEqual(sha(self.item.index),d['patched_sha256']);self.assertEqual(sha(self.root/d['script_name']),d['script_sha256'])
    def test_signed_app_and_outside_library_rejected(self):
        with self.assertRaises(RuntimeError):validate_cache(self.home/'Applications/Complete Anatomy.app/Contents/Resources/Mobile3D4MEngine',self.home)
        with self.assertRaises(RuntimeError):validate_cache(self.home/'Downloads/Mobile3D4MEngine',self.home)
        self.assertEqual(validate_cache(self.root,self.home),self.root.resolve())
    def test_app_and_uuid_container_discovery(self):
        app=self.home/'Applications/Complete Anatomy.app';(app/'Contents').mkdir(parents=True)
        with (app/'Contents/Info.plist').open('wb') as f:plistlib.dump({'CFBundleName':'Complete Anatomy','CFBundleIdentifier':'com.actual.mac.anatomy','CFBundleShortVersionString':'12.5-test'},f)
        info=app_info(app);self.assertEqual(info['bundle_id'],'com.actual.mac.anatomy')
        self.assertIn(info,discover_apps(self.home))
        container=self.home/'Library/Containers/random-uuid';container.mkdir()
        with (container/'.com.apple.containermanagerd.metadata.plist').open('wb') as f:plistlib.dump({'MCMMetadataIdentifier':info['bundle_id']},f)
        root=container/'Data/Library/Application Support/Mobile3D4MEngine';root.mkdir(parents=True);(root/'Resources/dist').mkdir(parents=True);(root/'index.html').write_bytes(self.original);(root/'Resources/dist/main.bundle.js').write_bytes(b'mac')
        self.assertEqual(discover_caches(info,self.home),[root])
    def test_helper_is_not_mistaken_for_original_app(self):
        helper=self.home/'Applications/VietHoa Complete Anatomy Mac.app';(helper/'Contents').mkdir(parents=True)
        with (helper/'Contents/Info.plist').open('wb') as f:plistlib.dump({'CFBundleDisplayName':'Việt hóa Complete Anatomy · Mac Test','CFBundleIdentifier':'vn.hungle.completeanatomy.vietnamese.mactest'},f)
        with self.assertRaises(RuntimeError):app_info(helper)
        self.assertEqual(discover_apps(self.home),[])
    def test_wrapped_app_and_path_name_fallback(self):
        app=self.home/'Applications/Medical/Complete Anatomy 2026.app';metadata=app/'Wrapper/CompleteAnatomy.app/Info.plist';metadata.parent.mkdir(parents=True)
        with metadata.open('wb') as f:plistlib.dump({'CFBundleName':'CA','CFBundleIdentifier':'com.actual.ios.CA'},f)
        info=app_info(app);self.assertEqual(info['application_kind'],'wrapped-ios');self.assertEqual(info['bundle_id'],'com.actual.ios.CA')
        self.assertIn(info,discover_apps(self.home))
    def test_unknown_html_and_csp_refused(self):
        self.item.index.write_bytes(b'<html><body>unrelated</body></html>')
        with self.assertRaises(RuntimeError):self.item.prepare(18768)
        self.item.index.write_bytes(self.original.replace(b'<head>',b'<head><meta http-equiv="Content-Security-Policy">'))
        with self.assertRaises(RuntimeError):self.item.prepare(18768)
    def test_wrong_target_registry_rejected(self):
        d=self.item.prepare(18768);d['target']='somewhere else';save(self.item.registry_path,d)
        with self.assertRaises(RuntimeError):self.item.apply()
    def test_authenticated_control_commands(self):
        with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
        d=self.item.prepare(port);self.item.apply();control=Control(self.item);control.start()
        def post(action,token=None,origin='null',**extra):
            req=urllib.request.Request('http://127.0.0.1:'+str(port)+'/command',data=json.dumps({'action':action,**extra}).encode(),headers={'Content-Type':'application/json','Origin':origin,'X-CAVi-Token':token or d['token']})
            with urllib.request.urlopen(req,timeout=5) as response:return json.loads(response.read())
        try:
            with self.assertRaises(urllib.error.HTTPError):post('uninstall',token='wrong')
            with self.assertRaises(urllib.error.HTTPError):post('uninstall',origin='https://untrusted.invalid')
            self.assertTrue(post('ready',version='0.7.21',language='vi')['ok']);self.assertTrue(control.ready)
            self.assertTrue(post('language',language='en')['ok'])
            self.assertTrue(post('uninstall')['ok']);self.assertTrue(control.finished.is_set());self.assertEqual(self.item.index.read_bytes(),self.original)
        finally:control.close()
if __name__=='__main__':unittest.main(verbosity=2)
