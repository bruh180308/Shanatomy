import json,socket,time,unittest,urllib.request,urllib.error
from types import SimpleNamespace
from cavi_mac import Control,VERSION
import test_mac as fixtures

class ConnectionTests(unittest.TestCase):
    setUp=fixtures.MacTests.setUp
    tearDown=fixtures.MacTests.tearDown
    def test_plain_transport_recovers_ready_and_preserves_auth(self):
        with socket.socket() as s:
            s.bind(('127.0.0.1',0));port=s.getsockname()[1]
        self.item.prepare(port);control=Control(self.item)
        control.auth=SimpleNamespace(snapshot=lambda:{'valid':True,'expires':2000000000})
        control.start();self.addCleanup(control.close)
        url='http://127.0.0.1:'+str(port)+'/command'
        def call(value,origin='null',header=None):
            headers={'Content-Type':'text/plain;charset=UTF-8','Origin':origin}
            if header is not None:headers['X-CAVi-Token']=header
            request=urllib.request.Request(url,data=json.dumps(value).encode(),headers=headers)
            with urllib.request.urlopen(request,timeout=5) as response:
                self.assertEqual(response.headers['Access-Control-Allow-Origin'],origin)
                return json.loads(response.read())
        body={'action':'license_status','version':VERSION,'token':control.d['token'],'viewport':{'width':500,'height':450}}
        self.assertFalse(control.ready)
        self.assertEqual(call(body)['license']['expires'],2000000000)
        self.assertTrue(control.ready);self.assertEqual(control.frontend['viewport']['height'],450)
        self.assertGreater(control.last_seen,0)
        for value,origin,header in [(dict(body,token='wrong'),'null',None),(body,'https://attacker.invalid',None),(body,'null','conflict'),(dict(body,version='0.7.20'),'null',None)]:
            with self.assertRaises(urllib.error.HTTPError):call(value,origin,header)
        self.assertEqual(call(body)['license']['expires'],2000000000,'rejected calls must not poison the controller')
        request=urllib.request.Request(url,method='OPTIONS',headers={'Origin':'null','Access-Control-Request-Private-Network':'true'})
        with urllib.request.urlopen(request,timeout=5) as response:
            self.assertEqual(response.status,204);self.assertEqual(response.headers['Access-Control-Allow-Private-Network'],'true')

if __name__=='__main__':unittest.main(verbosity=2)
