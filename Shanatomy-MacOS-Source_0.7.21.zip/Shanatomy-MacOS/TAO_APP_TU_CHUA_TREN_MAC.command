#!/bin/bash
set -e
CAVI_ROOT="$(cd -- "$(dirname -- "$0")" && pwd)"
CAVI_RES="$CAVI_ROOT/Shanatomy Mac.app/Contents/Resources"
if [ "$(uname -s)" != Darwin ]; then echo 'Chỉ dựng trên macOS.'; exit 1; fi
CAVI_PYTHON=/Library/Frameworks/Python.framework/Versions/Current/bin/python3
if [ ! -x "$CAVI_PYTHON" ]; then CAVI_PYTHON="$(command -v python3)"; fi
"$CAVI_PYTHON" -c 'import tkinter'
"$CAVI_PYTHON" -c 'import platform; assert platform.machine()=="arm64", "Dùng Python arm64 trên Apple Silicon để dựng gói này."'
"$CAVI_PYTHON" -m venv "$CAVI_ROOT/.mac_build_env"
"$CAVI_ROOT/.mac_build_env/bin/python" -m pip install 'pyinstaller==6.22.3' 'cryptography==50.0.1'
export PYTHONDONTWRITEBYTECODE=1
"$CAVI_ROOT/.mac_build_env/bin/python" -m PyInstaller --noconfirm --onefile --windowed --target-arch arm64 --name ShanatomyMac --osx-bundle-identifier vn.hungle.shanatomy.mac --icon "$CAVI_RES/icon.icns" --add-data "$CAVI_RES/assets:assets" --distpath "$CAVI_ROOT/BAN_TU_CHUA" --workpath "$CAVI_ROOT/.mac_build_work" --specpath "$CAVI_ROOT/.mac_build_work" "$CAVI_RES/cavi_mac.py"
/bin/mv "$CAVI_ROOT/BAN_TU_CHUA/ShanatomyMac.app" "$CAVI_ROOT/BAN_TU_CHUA/Shanatomy Mac.app"
"$CAVI_ROOT/.mac_build_env/bin/python" "$CAVI_RES/package_native.py" --app "$CAVI_ROOT/BAN_TU_CHUA/Shanatomy Mac.app" --out "$CAVI_ROOT/BAN_TU_CHUA/Shanatomy-MacOS.zip" --version 0.7.21
/usr/bin/open "$CAVI_ROOT/BAN_TU_CHUA"
echo 'Gửi ZIP tự chứa về máy giữ khóa ký để ký update-macos.json. Không dùng manifest của ZIP nguồn cho ZIP tự chứa.'
